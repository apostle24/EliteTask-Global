import { Timestamp } from 'firebase/firestore';

export type UserRole = 'client' | 'worker' | 'admin';
export type TaskStatus = 'open' | 'assigned' | 'in-progress' | 'completed' | 'cancelled';
export type ApplicationStatus = 'pending' | 'accepted' | 'rejected';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  verified: boolean;
  verificationRequested?: boolean;
  verificationDetails?: string;
  credits: number;
  isPremium: boolean;
  rating?: number;
  reviewCount?: number;
  photoURL?: string;
  bio?: string;
  skills?: string[];
  taxDetails?: {
    taxId: string;
    businessName: string;
    address: string;
  };
  createdAt: Timestamp | Date;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  budget: number;
  deadline: Timestamp | Date;
  status: TaskStatus;
  clientId: string;
  workerId?: string;
  category: string;
  imageUrl?: string;
  lat?: number;
  lng?: number;
  aiGenerated?: boolean;
  testQuestions?: {
    question: string;
    type: 'text' | 'multiple-choice';
    options?: string[];
  }[];
  paymentStatus?: 'pending' | 'paid';
  rating?: number;
  review?: string;
  createdAt: Timestamp | Date;
}

export interface TimeLog {
  id: string;
  workerId: string;
  startTime: Timestamp | Date;
  endTime?: Timestamp | Date;
  duration?: number; // in minutes
  description?: string;
}

export interface Application {
  id: string;
  taskId: string;
  workerId: string;
  workerName: string;
  workerPhoto?: string;
  coverLetter: string;
  status: ApplicationStatus;
  createdAt: Timestamp | Date;
}

export interface Message {
  id: string;
  taskId: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: Timestamp | Date;
}

export interface Notification {
  id: string;
  userId: string;
  type: string;
  message: string;
  read: boolean;
  createdAt: Timestamp | Date;
  taskId?: string;
}
