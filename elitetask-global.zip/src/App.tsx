import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './screens/Login';
import Signup from './screens/Signup';
import Onboarding from './screens/Onboarding';
import Dashboard from './screens/Dashboard';
import Marketplace from './screens/Marketplace';
import TaskDetail from './screens/TaskDetail';
import Chat from './screens/Chat';
import PostTask from './screens/PostTask';
import Upgrade from './screens/Upgrade';
import Profile from './screens/Profile';
import Notifications from './screens/Notifications';
import Messages from './screens/Messages';
import Layout from './components/Layout';
import AuthGuard from './components/AuthGuard';

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        
        {/* Protected Routes */}
        <Route path="/onboarding" element={
          <AuthGuard>
            <Onboarding />
          </AuthGuard>
        } />

        <Route path="/dashboard" element={
          <AuthGuard>
            <Layout>
              <Dashboard />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/marketplace" element={
          <AuthGuard>
            <Layout>
              <Marketplace />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/tasks/:taskId" element={
          <AuthGuard>
            <Layout>
              <TaskDetail />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/tasks/:taskId/chat" element={
          <AuthGuard>
            <Layout>
              <Chat />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/messages" element={
          <AuthGuard>
            <Layout>
              <Messages />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/post-task" element={
          <AuthGuard requireRole="client">
            <Layout>
              <PostTask />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/upgrade" element={
          <AuthGuard>
            <Layout>
              <Upgrade />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/profile" element={
          <AuthGuard>
            <Layout>
              <Profile />
            </Layout>
          </AuthGuard>
        } />

        <Route path="/notifications" element={
          <AuthGuard>
            <Layout>
              <Notifications />
            </Layout>
          </AuthGuard>
        } />

        {/* Fallback */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Router>
  );
}
