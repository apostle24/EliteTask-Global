import { db } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { UserProfile } from '../types';

export const updateTaxDetails = async (userId: string, taxDetails: UserProfile['taxDetails']) => {
  const userRef = doc(db, 'users', userId);
  await updateDoc(userRef, { taxDetails });
};

export const generateTaxInvoice = (task: any, user: UserProfile) => {
  // Mock invoice generation
  console.log('Generating invoice for task:', task.id, 'for user:', user.name);
  return {
    invoiceId: `INV-${Math.floor(Math.random() * 1000000)}`,
    date: new Date().toISOString(),
    amount: task.budget,
    taxAmount: task.budget * 0.15, // 15% tax
    total: task.budget * 1.15,
    businessName: user.taxDetails?.businessName || user.name,
    taxId: user.taxDetails?.taxId || 'N/A',
  };
};
