import { db } from '../firebase';
import { collection, query, where, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { Task, UserProfile } from '../types';

export const automationService = {
  /**
   * Automatically matches a new task with relevant workers and notifies them.
   */
  async matchAndNotifyWorkers(task: Partial<Task> & { id: string }) {
    try {
      // 1. Find workers with matching skills or category
      const workersRef = collection(db, 'users');
      const q = query(
        workersRef, 
        where('role', '==', 'worker'),
        where('verified', '==', true)
      );
      
      const querySnapshot = await getDocs(q);
      const workers = querySnapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));

      // 2. Simple matching logic: check if category matches or description contains skills
      const matchedWorkers = workers.filter(worker => {
        const hasMatchingCategory = worker.skills?.some(skill => 
          task.category?.toLowerCase().includes(skill.toLowerCase()) ||
          task.title?.toLowerCase().includes(skill.toLowerCase())
        );
        return hasMatchingCategory;
      });

      // 3. Create notifications for matched workers
      const notificationPromises = matchedWorkers.map(worker => {
        const notificationsRef = collection(db, 'users', worker.uid, 'notifications');
        return addDoc(notificationsRef, {
          type: 'smart_match',
          message: `Smart Match: A new task "${task.title}" matches your skills!`,
          taskId: task.id,
          read: false,
          createdAt: serverTimestamp(),
        });
      });

      await Promise.all(notificationPromises);
      console.log(`Automation: Notified ${matchedWorkers.length} workers about task ${task.id}`);
    } catch (error) {
      console.error("Automation error:", error);
    }
  }
};
