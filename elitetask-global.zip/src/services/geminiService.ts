import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function smartSearch(query: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `The user is searching for "${query}" in a task marketplace app. 
      Provide a helpful summary of what they might be looking for and suggest 3-5 categories or specific task types that would be relevant. 
      Keep it concise and professional.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    return response.text;
  } catch (error) {
    console.error("Smart search error:", error);
    return null;
  }
}
