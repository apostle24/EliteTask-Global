import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { signOut } from 'firebase/auth';
import { collection, query, onSnapshot, orderBy, limit, updateDoc, doc, getDocs, where, getDocFromServer } from 'firebase/firestore';
import { Notification, Task } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { smartSearch } from '../services/geminiService';
import { 
  LayoutDashboard, 
  Briefcase, 
  MessageSquare, 
  Bell, 
  User, 
  LogOut, 
  PlusCircle,
  Menu,
  X,
  Search,
  ChevronRight,
  Settings,
  HelpCircle,
  Clock,
  Check,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { cn } from '../utils/cn';
import { format } from 'date-fns';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!profile) return;
    
    // Test connection to Firestore
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. The client is offline.");
        }
      }
    };
    testConnection();

    const notifsRef = collection(db, 'users', profile.uid, 'notifications');
    const q = query(notifsRef, orderBy('createdAt', 'desc'), limit(5));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notifList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification));
      setNotifications(notifList);
      setUnreadCount(notifList.filter(n => !n.read).length);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, notifsRef.path);
    });
    return () => unsubscribe();
  }, [profile]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Task[]>([]);
  const [smartResults, setSmartResults] = useState<string | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsSearchFocused(false);
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const searchTasks = async () => {
      if (searchQuery.length < 2) {
        setSearchResults([]);
        setSmartResults(null);
        return;
      }
      setIsSearching(true);
      try {
        const tasksRef = collection(db, 'tasks');
        const q = query(tasksRef, where('status', '==', 'open'), limit(100));
        const snapshot = await getDocs(q).catch(err => handleFirestoreError(err, OperationType.GET, tasksRef.path));
        if (!snapshot) return;
        const allTasks = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task));
        const filtered = allTasks.filter(t => 
          t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.category.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setSearchResults(filtered);

        // Call smart search for AI-powered suggestions
        const aiSummary = await smartSearch(searchQuery);
        setSmartResults(aiSummary);
      } catch (error) {
        console.error("Search error:", error);
      } finally {
        setIsSearching(false);
      }
    };

    const timer = setTimeout(searchTasks, 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const markAsRead = async (notifId: string) => {
    if (!profile) return;
    await updateDoc(doc(db, 'users', profile.uid, 'notifications', notifId), {
      read: true
    });
  };

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Marketplace', path: '/marketplace', icon: Briefcase },
    { name: 'Messages', path: '/messages', icon: MessageSquare },
    { name: 'Notifications', path: '/notifications', icon: Bell },
    { name: 'Profile', path: '/profile', icon: User },
  ];

  if (profile?.role === 'client') {
    navItems.splice(2, 0, { name: 'Post Task', path: '/post-task', icon: PlusCircle });
  }

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col md:flex-row">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-72 bg-white border-r border-zinc-200 sticky top-0 h-screen z-40">
        <div className="p-8">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-brand-600/20 group-hover:scale-110 transition-transform">
              <Briefcase size={24} />
            </div>
            <span className="text-xl font-extrabold text-zinc-900 tracking-tight">EliteTask<span className="text-brand-600">Global</span></span>
          </Link>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          <div className="px-4 mb-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Main Menu</p>
          </div>
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.name}
                to={item.path}
                className={cn(
                  "group flex items-center justify-between px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                  isActive 
                    ? "bg-brand-50 text-brand-700 shadow-sm" 
                    : "text-zinc-500 hover:bg-zinc-50 hover:text-zinc-900"
                )}
              >
                <div className="flex items-center gap-3">
                  <item.icon size={20} className={cn(isActive ? "text-brand-600" : "text-zinc-400 group-hover:text-zinc-600")} />
                  {item.name}
                </div>
                {isActive && (
                  <motion.div layoutId="active-pill" className="w-1.5 h-1.5 rounded-full bg-brand-600" />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="p-6 border-t border-zinc-100">
          <div className="bg-zinc-50 rounded-2xl p-4 mb-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-brand-100 flex items-center justify-center text-brand-700 font-bold overflow-hidden shadow-inner">
                {profile?.photoURL ? (
                  <img src={profile.photoURL} alt={profile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  profile?.name?.charAt(0) || 'U'
                )}
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-sm font-bold text-zinc-900 truncate">{profile?.name || 'User'}</p>
                <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">{profile?.role || 'Loading...'}</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut size={14} />
              Sign Out
            </button>
          </div>
          
          <div className="flex items-center justify-between px-2">
            <button className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"><Settings size={18} /></button>
            <button className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"><HelpCircle size={18} /></button>
            <div className="text-[10px] font-bold text-zinc-300">v2.1.0</div>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className={cn(
        "md:hidden fixed top-0 inset-x-0 z-50 transition-all duration-300 px-4 py-3 flex justify-between items-center",
        scrolled ? "glass shadow-sm" : "bg-white border-b border-zinc-200"
      )}>
        <Link to="/" className="text-xl font-extrabold text-zinc-900 tracking-tight">EliteTask<span className="text-brand-600">Global</span></Link>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsSearchFocused(true)}
            className="p-2 text-zinc-600 bg-zinc-100 rounded-xl active:scale-95 transition-transform"
          >
            <Search size={20} />
          </button>
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)} 
            className="p-2 text-zinc-600 bg-zinc-100 rounded-xl active:scale-95 transition-transform"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm z-40 md:hidden"
              onClick={() => setIsMenuOpen(false)}
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-72 bg-white z-50 md:hidden flex flex-col p-6 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-10">
                <span className="text-xl font-extrabold text-zinc-900 tracking-tight">EliteTask<span className="text-brand-600">Global</span></span>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 text-zinc-400"><X size={20} /></button>
              </div>
              
              <nav className="flex-1 space-y-2">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-4 rounded-2xl text-base font-bold transition-all",
                      location.pathname === item.path 
                        ? "bg-brand-600 text-white shadow-lg shadow-brand-600/30" 
                        : "text-zinc-500 hover:bg-zinc-50"
                    )}
                  >
                    <item.icon size={22} />
                    {item.name}
                  </Link>
                ))}
              </nav>

              <div className="mt-auto pt-6 border-t border-zinc-100">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl text-base font-bold text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut size={22} />
                  Logout
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 pt-16 md:pt-0">
        {/* Top Bar - Desktop */}
        <div className="hidden md:flex h-20 items-center justify-between px-8 bg-white border-b border-zinc-200 sticky top-0 z-30">
          <div className="relative w-full max-w-xl group" ref={searchRef}>
            <div className={cn(
              "relative z-50 flex items-center bg-zinc-50 border border-zinc-200 rounded-2xl transition-all duration-300",
              isSearchFocused ? "ring-4 ring-brand-500/10 border-brand-500 bg-white" : "hover:border-zinc-300"
            )}>
              <Search className={cn(
                "ml-4 text-zinc-400 transition-colors",
                isSearchFocused && "text-brand-600"
              )} size={18} />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                placeholder="Search for tasks, categories, or skills..." 
                className="w-full pl-3 pr-4 py-2.5 bg-transparent outline-none text-sm font-medium placeholder:text-zinc-400"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="mr-3 p-1 text-zinc-400 hover:text-zinc-600 transition-colors"
                >
                  <X size={14} />
                </button>
              )}
            </div>
            
            <AnimatePresence>
              {isSearchFocused && (
                <>
                  {/* Backdrop Overlay */}
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-zinc-900/40 backdrop-blur-md z-[60] md:z-40"
                    onClick={() => setIsSearchFocused(false)}
                  />
                  
                  {/* Dropdown/Modal Results */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 20, scale: 0.95 }}
                    className={cn(
                      "fixed inset-x-4 top-20 bottom-4 md:absolute md:inset-auto md:top-full md:left-0 md:w-full md:mt-3 bg-white border border-zinc-200 rounded-[2rem] shadow-2xl z-[70] md:z-50 overflow-hidden flex flex-col",
                      "md:max-h-[80vh]"
                    )}
                  >
                    {/* Mobile Search Input (Only visible on mobile modal) */}
                    <div className="md:hidden p-4 border-b border-zinc-100 flex items-center gap-3">
                      <Search size={20} className="text-zinc-400" />
                      <input 
                        type="text" 
                        autoFocus
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search marketplace..." 
                        className="flex-1 bg-transparent outline-none text-base font-medium"
                      />
                      <button onClick={() => setIsSearchFocused(false)} className="p-2 text-zinc-400">
                        <X size={20} />
                      </button>
                    </div>

                    {searchQuery.length < 2 ? (
                      <div className="p-8">
                        <div className="text-center mb-8">
                          <div className="w-12 h-12 bg-zinc-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-zinc-300">
                            <Search size={24} />
                          </div>
                          <p className="text-sm font-bold text-zinc-900">Start typing to search</p>
                          <p className="text-xs text-zinc-400 mt-1">Find tasks, experts, or categories</p>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          {['Design', 'Development', 'Marketing', 'Writing'].map(cat => (
                            <button
                              key={cat}
                              onClick={() => setSearchQuery(cat)}
                              className="px-4 py-3 rounded-2xl bg-zinc-50 border border-zinc-100 text-xs font-bold text-zinc-600 hover:bg-brand-50 hover:border-brand-200 hover:text-brand-600 transition-all text-left"
                            >
                              {cat}
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="overflow-y-auto custom-scrollbar">
                        {isSearching ? (
                          <div className="p-12 text-center">
                            <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                            <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Analyzing marketplace...</p>
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-zinc-100">
                            {/* Smart Suggestions - Left Side (or top on small) */}
                            <div className="lg:col-span-4 bg-zinc-50/50 p-6 relative overflow-hidden">
                              <div className="relative z-10">
                                <div className="flex items-center gap-2 mb-6">
                                  <div className="w-8 h-8 bg-brand-100 rounded-xl flex items-center justify-center text-brand-600 shadow-sm border border-brand-200/50">
                                    <Sparkles size={16} />
                                  </div>
                                  <div>
                                    <h3 className="text-xs font-extrabold text-zinc-900 uppercase tracking-widest">Smart Suggestions</h3>
                                    <p className="text-[10px] text-zinc-400 font-bold">AI Insights</p>
                                  </div>
                                </div>
                                
                                {smartResults ? (
                                  <motion.div 
                                    initial={{ opacity: 0, y: 5 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="space-y-4"
                                  >
                                    <div className="bg-white p-5 rounded-2xl border border-zinc-200 shadow-sm">
                                      <p className="text-sm text-zinc-700 leading-relaxed font-medium italic">
                                        "{smartResults}"
                                      </p>
                                    </div>
                                    
                                    <div className="p-4 bg-brand-50 rounded-2xl border border-brand-100">
                                      <div className="flex items-center gap-2 mb-2">
                                        <div className="w-1.5 h-1.5 rounded-full bg-brand-500" />
                                        <p className="text-[10px] font-bold text-brand-700 uppercase tracking-tighter">Pro Tip</p>
                                      </div>
                                      <p className="text-[11px] text-brand-800 leading-snug">
                                        Try adding specific skills like "React" or "Copywriting" to get even more precise matches.
                                      </p>
                                    </div>
                                  </motion.div>
                                ) : (
                                  <div className="py-12 text-center">
                                    <div className="w-10 h-10 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                                    <p className="text-[10px] font-bold text-brand-600 uppercase tracking-widest animate-pulse">Generating insights...</p>
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Search Results - Right Side (or bottom on small) */}
                            <div className="lg:col-span-8 p-6 bg-white">
                              <div className="flex items-center justify-between mb-6">
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 bg-zinc-100 rounded-xl flex items-center justify-center text-zinc-600">
                                    <Briefcase size={16} />
                                  </div>
                                  <div>
                                    <h3 className="text-xs font-extrabold text-zinc-900 uppercase tracking-widest">Marketplace Results</h3>
                                    <p className="text-[10px] text-zinc-400 font-bold">{searchResults.length} tasks found</p>
                                  </div>
                                </div>
                                {searchResults.length > 0 && (
                                  <Link 
                                    to="/marketplace" 
                                    onClick={() => setIsSearchFocused(false)}
                                    className="text-[10px] font-bold text-brand-600 hover:underline flex items-center gap-1"
                                  >
                                    View All <ChevronRight size={12} />
                                  </Link>
                                )}
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {searchResults.length > 0 ? (
                                  searchResults.map((task, idx) => (
                                    <motion.div
                                      key={task.id}
                                      initial={{ opacity: 0, x: 10 }}
                                      animate={{ opacity: 1, x: 0 }}
                                      transition={{ delay: idx * 0.05 }}
                                    >
                                      <Link 
                                        to={`/tasks/${task.id}`}
                                        onClick={() => {
                                          setSearchQuery('');
                                          setIsSearchFocused(false);
                                        }}
                                        className="flex items-center gap-4 p-4 rounded-2xl bg-zinc-50 hover:bg-white border border-transparent hover:border-zinc-200 hover:shadow-md transition-all group"
                                      >
                                        <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-zinc-400 group-hover:bg-brand-100 group-hover:text-brand-600 transition-colors shadow-sm">
                                          <Briefcase size={18} />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                          <h4 className="text-sm font-bold text-zinc-900 truncate group-hover:text-brand-600 transition-colors">{task.title}</h4>
                                          <div className="flex items-center gap-2 mt-1">
                                            <span className="text-[9px] font-extrabold uppercase tracking-widest text-zinc-400 bg-white px-1.5 py-0.5 rounded border border-zinc-100">
                                              {task.category}
                                            </span>
                                            <span className="text-[10px] font-bold text-emerald-600">${task.budget}</span>
                                          </div>
                                        </div>
                                        <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-zinc-300 group-hover:bg-brand-600 group-hover:text-white transition-all shadow-sm">
                                          <ArrowRight size={14} />
                                        </div>
                                      </Link>
                                    </motion.div>
                                  ))
                                ) : (
                                  <div className="col-span-full py-12 text-center">
                                    <div className="w-12 h-12 bg-zinc-50 rounded-full flex items-center justify-center mx-auto mb-4 text-zinc-300">
                                      <Search size={24} />
                                    </div>
                                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest">No matching tasks</p>
                                    <p className="text-[10px] text-zinc-400 mt-1">Try different keywords or check categories</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                    
                    {/* Footer */}
                    <div className="p-4 bg-zinc-50 border-t border-zinc-100 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1.5">
                          <kbd className="px-1.5 py-0.5 bg-white border border-zinc-200 rounded text-[10px] font-bold text-zinc-500">ESC</kbd>
                          <span className="text-[10px] text-zinc-400 font-medium">to close</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-[10px] text-zinc-400 font-medium">
                        Powered by <span className="text-brand-600 font-bold">Gemini AI</span>
                      </div>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative" ref={notificationRef}>
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className={cn(
                  "relative p-2.5 text-zinc-500 hover:bg-zinc-100 rounded-xl transition-colors",
                  showNotifications && "bg-zinc-100 text-brand-600"
                )}
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2 w-4 h-4 bg-red-500 border-2 border-white rounded-full text-[8px] flex items-center justify-center text-white font-bold">
                    {unreadCount}
                  </span>
                )}
              </button>

              <AnimatePresence>
                {showNotifications && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-80 bg-white border border-zinc-200 rounded-2xl shadow-xl z-50 overflow-hidden"
                  >
                    <div className="p-4 border-b border-zinc-100 flex justify-between items-center">
                      <h3 className="font-bold text-zinc-900">Notifications</h3>
                      <Link to="/notifications" onClick={() => setShowNotifications(false)} className="text-xs text-brand-600 font-bold hover:underline">View All</Link>
                    </div>
                    <div className="max-h-96 overflow-y-auto divide-y divide-zinc-50">
                      {notifications.length > 0 ? (
                        notifications.map((notif) => (
                          <div 
                            key={notif.id} 
                            className={cn(
                              "p-4 hover:bg-zinc-50 transition-colors cursor-pointer flex gap-3",
                              !notif.read && "bg-brand-50/30"
                            )}
                            onClick={() => {
                              if (!notif.read) markAsRead(notif.id);
                              if (notif.taskId) navigate(`/tasks/${notif.taskId}`);
                              setShowNotifications(false);
                            }}
                          >
                            <div className={cn(
                              "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                              !notif.read ? "bg-brand-100 text-brand-600" : "bg-zinc-100 text-zinc-400"
                            )}>
                              <Bell size={14} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className={cn("text-xs leading-snug", !notif.read ? "text-zinc-900 font-bold" : "text-zinc-500")}>
                                {notif.message}
                              </p>
                              <div className="flex items-center gap-1 mt-1 text-[8px] text-zinc-400">
                                <Clock size={10} />
                                {format(notif.createdAt instanceof Date ? notif.createdAt : (notif.createdAt as any).toDate(), 'MMM d, HH:mm')}
                              </div>
                            </div>
                            {!notif.read && <div className="w-1.5 h-1.5 rounded-full bg-brand-600 mt-2 shrink-0" />}
                          </div>
                        ))
                      ) : (
                        <div className="p-8 text-center">
                          <p className="text-xs text-zinc-400">No notifications yet</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <div className="h-8 w-px bg-zinc-200 mx-2" />
            <Link to="/profile" className="flex items-center gap-3 group">
              <div className="text-right hidden lg:block">
                <p className="text-xs font-bold text-zinc-900 group-hover:text-brand-600 transition-colors">{profile?.name || 'User'}</p>
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-tighter">{profile?.role || 'Role'}</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-brand-100 flex items-center justify-center text-brand-700 font-bold overflow-hidden border-2 border-transparent group-hover:border-brand-500 transition-all">
                {profile?.photoURL ? (
                  <img src={profile.photoURL} alt={profile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  profile?.name?.charAt(0) || 'U'
                )}
              </div>
            </Link>
          </div>
        </div>

        <div className="flex-1 p-4 md:p-10 overflow-x-hidden">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="max-w-7xl mx-auto"
          >
            {children}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
