import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { doc, updateDoc, increment } from 'firebase/firestore';
import { 
  Zap, 
  Check, 
  CreditCard, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight,
  Star,
  Globe,
  Lock,
  Building2,
  Receipt,
  Plus
} from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../hooks/useAuth';
import { updateTaxDetails } from '../services/taxService';

export default function Upgrade() {
  const { profile } = useAuth();
  const [loading, setLoading] = useState<string | null>(null);
  const [showTaxForm, setShowTaxForm] = useState(false);
  const [taxId, setTaxId] = useState(profile?.taxDetails?.taxId || '');
  const [businessName, setBusinessName] = useState(profile?.taxDetails?.businessName || '');
  const [address, setAddress] = useState(profile?.taxDetails?.address || '');
  const [paymentMethods, setPaymentMethods] = useState<{ id: string; type: 'card' | 'paypal'; last4?: string; email?: string }[]>([
    { id: '1', type: 'card', last4: '4242' }
  ]);
  const [showAddPayment, setShowAddPayment] = useState(false);
  const [newCard, setNewCard] = useState({ number: '', expiry: '', cvc: '' });
  const navigate = useNavigate();

  const handleAddPayment = () => {
    if (newCard.number.length < 16) return;
    setPaymentMethods([...paymentMethods, { 
      id: Math.random().toString(), 
      type: 'card', 
      last4: newCard.number.slice(-4) 
    }]);
    setShowAddPayment(false);
    setNewCard({ number: '', expiry: '', cvc: '' });
  };

  const handlePurchase = async (type: 'credits' | 'premium', amount: number) => {
    if (!auth.currentUser) return;
    setLoading(type === 'credits' ? 'credits' : 'premium');
    
    // Simulate payment gateway delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      
      // Save tax details if provided
      if (taxId && businessName && address) {
        await updateTaxDetails(auth.currentUser.uid, { taxId, businessName, address });
      }

      if (type === 'credits') {
        await updateDoc(userRef, {
          credits: increment(amount)
        }).catch(err => handleFirestoreError(err, OperationType.UPDATE, userRef.path));
      } else {
        await updateDoc(userRef, {
          isPremium: true,
          credits: increment(50) // Bonus credits for premium
        }).catch(err => handleFirestoreError(err, OperationType.UPDATE, userRef.path));
      }
      alert(`Success! Your ${type} have been updated.`);
      navigate('/dashboard');
    } catch (error) {
      console.error("Purchase error:", error);
      handleFirestoreError(error, OperationType.UPDATE, `users/${auth.currentUser.uid}`);
    } finally {
      setLoading(null);
    }
  };

  const plans = [
    {
      id: 'credits',
      name: 'Credit Pack',
      price: '$9.99',
      description: 'Perfect for occasional task posting',
      features: [
        '20 Task Credits',
        'Standard Support',
        'AI Polish Access',
        'No Expiry'
      ],
      action: () => handlePurchase('credits', 20),
      icon: <CreditCard className="text-zinc-600" />,
      color: 'bg-zinc-50',
      borderColor: 'border-zinc-200',
      buttonColor: 'bg-zinc-900 hover:bg-zinc-800'
    },
    {
      id: 'premium',
      name: 'Premium Pro',
      price: '$29.99',
      description: 'The ultimate power for serious users',
      features: [
        'Unlimited Task Posting',
        '50 Bonus Credits',
        'Priority Matching',
        'Verified Badge',
        'Advanced AI Tools',
        '24/7 VIP Support'
      ],
      action: () => handlePurchase('premium', 0),
      icon: <Zap className="text-brand-600" fill="currentColor" />,
      color: 'bg-brand-50',
      borderColor: 'border-brand-200',
      buttonColor: 'bg-brand-600 hover:bg-brand-500',
      popular: true
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-bold mb-4"
        >
          <Sparkles size={14} />
          Elevate Your Experience
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl font-black text-zinc-900 mb-4"
        >
          Choose Your Power Level
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-zinc-500 max-w-2xl mx-auto"
        >
          Unlock unlimited potential, AI-powered tools, and priority matching to get your work done faster and better than ever.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
        {plans.map((plan, idx) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, x: idx === 0 ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 + idx * 0.1 }}
            className={`relative p-8 rounded-3xl border-2 ${plan.borderColor} ${plan.color} flex flex-col`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-brand-600 text-white px-4 py-1 rounded-full text-xs font-bold shadow-lg">
                MOST POPULAR
              </div>
            )}
            
            <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center mb-6">
              {plan.icon}
            </div>

            <h3 className="text-2xl font-black text-zinc-900 mb-1">{plan.name}</h3>
            <p className="text-sm text-zinc-500 mb-6">{plan.description}</p>
            
            <div className="mb-8">
              <span className="text-4xl font-black text-zinc-900">{plan.price}</span>
              <span className="text-zinc-500 text-sm ml-1">/ one-time</span>
            </div>

            <div className="space-y-4 mb-10 flex-grow">
              {plan.features.map((feature, fIdx) => (
                <div key={fIdx} className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center ${plan.popular ? 'bg-brand-200 text-brand-700' : 'bg-zinc-200 text-zinc-700'}`}>
                    <Check size={12} strokeWidth={3} />
                  </div>
                  <span className="text-sm font-medium text-zinc-700">{feature}</span>
                </div>
              ))}
            </div>

            <button
              onClick={plan.action}
              disabled={!!loading || (plan.id === 'premium' && profile?.isPremium)}
              className={`w-full py-4 rounded-2xl text-white font-bold transition-all flex items-center justify-center gap-2 shadow-lg ${plan.buttonColor} disabled:opacity-50`}
            >
              {loading === plan.id ? (
                <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  {plan.id === 'premium' && profile?.isPremium ? 'Already Premium' : `Get ${plan.name}`}
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </motion.div>
        ))}
      </div>

      {/* Tax Details Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="max-w-4xl mx-auto p-8 rounded-3xl border-2 border-zinc-200 bg-white shadow-sm"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-zinc-100 text-zinc-600 flex items-center justify-center">
              <Receipt size={20} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-zinc-900">Tax & Billing Information</h3>
              <p className="text-sm text-zinc-500">Add your details for tax-deductible invoices</p>
            </div>
          </div>
          <button 
            onClick={() => setShowTaxForm(!showTaxForm)}
            className="text-sm font-bold text-brand-600 hover:text-brand-700"
          >
            {showTaxForm ? 'Cancel' : (profile?.taxDetails ? 'Edit Details' : 'Add Details')}
          </button>
        </div>

        {showTaxForm ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Business Name</label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input 
                  type="text"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="e.g. Acme Corp"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-zinc-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-none transition-all"
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Tax ID / VAT Number</label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
                <input 
                  type="text"
                  value={taxId}
                  onChange={(e) => setTaxId(e.target.value)}
                  placeholder="e.g. US123456789"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-zinc-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-none transition-all"
                />
              </div>
            </div>
            <div className="md:col-span-2 space-y-1">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Billing Address</label>
              <textarea 
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Full billing address..."
                rows={2}
                className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-none transition-all resize-none"
              />
            </div>
            <div className="md:col-span-2">
              <button 
                onClick={() => setShowTaxForm(false)}
                className="w-full py-3 rounded-xl bg-zinc-900 text-white font-bold hover:bg-zinc-800 transition-all"
              >
                Save Billing Details
              </button>
            </div>
          </div>
        ) : profile?.taxDetails ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4 rounded-2xl bg-zinc-50 border border-zinc-100">
            <div>
              <p className="text-xs font-bold text-zinc-400 uppercase mb-1">Business</p>
              <p className="text-sm font-medium text-zinc-900">{profile.taxDetails.businessName}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-400 uppercase mb-1">Tax ID</p>
              <p className="text-sm font-medium text-zinc-900">{profile.taxDetails.taxId}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-400 uppercase mb-1">Address</p>
              <p className="text-sm font-medium text-zinc-900 truncate">{profile.taxDetails.address}</p>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-zinc-50 border border-dashed border-zinc-300 text-center">
            <p className="text-sm text-zinc-500 italic">No billing details added yet. Add them to receive tax-compliant invoices.</p>
          </div>
        )}
      </motion.div>

      {/* Payment Methods */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="max-w-4xl mx-auto mt-12 bg-white rounded-[2.5rem] border border-zinc-200 shadow-sm overflow-hidden"
      >
        <div className="p-8 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center">
              <CreditCard size={20} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-zinc-900">Payment Methods</h2>
              <p className="text-sm text-zinc-500">Manage your cards and billing accounts.</p>
            </div>
          </div>
          <button 
            onClick={() => setShowAddPayment(true)}
            className="px-4 py-2 bg-zinc-900 text-white rounded-xl text-xs font-bold hover:bg-zinc-800 transition-all flex items-center gap-2"
          >
            <Plus size={14} /> Add New
          </button>
        </div>

        <div className="p-8 space-y-4">
          {paymentMethods.map(method => (
            <div key={method.id} className="flex items-center justify-between p-4 rounded-2xl border border-zinc-100 bg-zinc-50/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-8 bg-white border border-zinc-200 rounded flex items-center justify-center">
                  {method.type === 'card' ? <CreditCard size={16} className="text-zinc-400" /> : <span className="text-[8px] font-bold text-blue-600">PayPal</span>}
                </div>
                <div>
                  <p className="text-sm font-bold text-zinc-900">
                    {method.type === 'card' ? `•••• •••• •••• ${method.last4}` : method.email}
                  </p>
                  <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">Expires 12/28</p>
                </div>
              </div>
              <button className="text-xs font-bold text-red-600 hover:underline">Remove</button>
            </div>
          ))}

          {showAddPayment && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-6 rounded-2xl border-2 border-dashed border-zinc-200 space-y-4"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-full">
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5">Card Number</label>
                  <input 
                    type="text" 
                    placeholder="0000 0000 0000 0000"
                    value={newCard.number}
                    onChange={(e) => setNewCard({...newCard, number: e.target.value.replace(/\D/g, '').slice(0, 16)})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5">Expiry Date</label>
                  <input 
                    type="text" 
                    placeholder="MM/YY"
                    value={newCard.expiry}
                    onChange={(e) => setNewCard({...newCard, expiry: e.target.value})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5">CVC</label>
                  <input 
                    type="text" 
                    placeholder="123"
                    value={newCard.cvc}
                    onChange={(e) => setNewCard({...newCard, cvc: e.target.value.replace(/\D/g, '').slice(0, 3)})}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowAddPayment(false)}
                  className="flex-1 py-3 border border-zinc-200 text-zinc-600 rounded-xl font-bold hover:bg-zinc-50 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddPayment}
                  className="flex-1 py-3 bg-zinc-900 text-white rounded-xl font-bold hover:bg-zinc-800 transition-all"
                >
                  Save Card
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>

      {/* Global Publishing Guide */}
      <div className="mt-20 bg-zinc-900 text-white p-12 rounded-[3rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-500/10 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-brand-500/20 text-brand-400 flex items-center justify-center">
              <Globe size={24} />
            </div>
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Go Global</h2>
              <p className="text-zinc-400">How to publish your app for the world</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-xs font-bold text-brand-400 border border-zinc-700">1</div>
              <h3 className="font-bold text-lg">Connect Domain</h3>
              <p className="text-sm text-zinc-400 leading-relaxed">
                Go to the <strong>Settings</strong> menu and select <strong>Domains</strong> to connect your own custom .com or .io domain.
              </p>
            </div>
            <div className="space-y-4">
              <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-xs font-bold text-brand-400 border border-zinc-700">2</div>
              <h3 className="font-bold text-lg">Configure SEO</h3>
              <p className="text-sm text-zinc-400 leading-relaxed">
                Update your <code>metadata.json</code> with a compelling name and description to ensure your marketplace ranks on search engines.
              </p>
            </div>
            <div className="space-y-4">
              <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-xs font-bold text-brand-400 border border-zinc-700">3</div>
              <h3 className="font-bold text-lg">Deploy to Cloud</h3>
              <p className="text-sm text-zinc-400 leading-relaxed">
                Use the <strong>Deploy</strong> button in the top bar to push your app to our global edge network for lightning-fast access.
              </p>
            </div>
          </div>

          <div className="mt-12 p-6 rounded-2xl bg-zinc-800/50 border border-zinc-700 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <ShieldCheck size={20} />
              </div>
              <p className="text-sm text-zinc-300">Your app is already optimized for global scale and security.</p>
            </div>
            <button className="px-6 py-3 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-xl transition-all whitespace-nowrap">
              Start Deployment
            </button>
          </div>
        </div>
      </div>

      <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
        <div className="p-6">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4">
            <ShieldCheck size={24} />
          </div>
          <h4 className="font-bold text-zinc-900 mb-2">Secure Payments</h4>
          <p className="text-xs text-zinc-500">Processed via Stripe & PayPal with 256-bit encryption.</p>
        </div>
        <div className="p-6">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
            <Globe size={24} />
          </div>
          <h4 className="font-bold text-zinc-900 mb-2">Global Access</h4>
          <p className="text-xs text-zinc-500">Post tasks and find workers from anywhere in the world.</p>
        </div>
        <div className="p-6">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-4">
            <Lock size={24} />
          </div>
          <h4 className="font-bold text-zinc-900 mb-2">Money Back Guarantee</h4>
          <p className="text-xs text-zinc-500">Not satisfied? Get a full refund within 14 days of purchase.</p>
        </div>
      </div>
    </div>
  );
}
