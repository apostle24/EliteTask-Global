import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { Task } from '../types';
import { 
  Search, 
  Filter, 
  Briefcase, 
  MapPin, 
  DollarSign, 
  Clock,
  ArrowRight,
  TrendingUp,
  Zap,
  ShieldCheck,
  LayoutGrid,
  List as ListIcon,
  Map as MapIcon,
  Star,
  CheckCircle2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { cn } from '../utils/cn';
import { motion, AnimatePresence } from 'motion/react';
import { APIProvider, Map, AdvancedMarker, Pin, InfoWindow, useAdvancedMarkerRef } from '@vis.gl/react-google-maps';

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

function MarkerWithInfoWindow({ task }: { task: Task }) {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const [open, setOpen] = useState(false);

  if (!task.lat || !task.lng) return null;

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: task.lat, lng: task.lng }}
        onClick={() => setOpen(true)}
      >
        <Pin 
          background={(task as any).isFeatured ? "#f59e0b" : "#10b981"} 
          glyphColor="#fff" 
          borderColor={(task as any).isFeatured ? "#d97706" : "#059669"} 
        />
      </AdvancedMarker>
      {open && (
        <InfoWindow anchor={marker} onCloseClick={() => setOpen(false)}>
          <div className="p-2 max-w-[200px]">
            {(task as any).isFeatured && (
              <div className="flex items-center gap-1 text-[8px] font-extrabold uppercase tracking-widest text-amber-600 mb-1">
                <Star size={8} fill="currentColor" />
                Featured
              </div>
            )}
            <h4 className="font-bold text-zinc-900 text-sm mb-1">{task.title}</h4>
            <div className="flex items-center gap-1 text-[10px] text-zinc-500 mb-2">
              <MapPin size={10} />
              {task.category}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-emerald-600 font-bold text-xs">${task.budget}</span>
              <Link 
                to={`/tasks/${task.id}`}
                className="text-[10px] font-bold text-brand-600 hover:underline flex items-center gap-0.5"
              >
                View <ArrowRight size={10} />
              </Link>
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
}

export default function Marketplace() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [appliedSearchTerm, setAppliedSearchTerm] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [filter, setFilter] = useState('all');
  const [category, setCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'map'>('grid');
  const [budgetRange, setBudgetRange] = useState<[number, number]>([0, 10000]);
  const [sortBy, setSortBy] = useState<'newest' | 'budget-high' | 'budget-low'>('newest');
  const [showFilters, setShowFilters] = useState(false);

  const categories = [
    { id: 'all', name: 'All Categories', icon: LayoutGrid },
    { id: 'Design', name: 'Design', icon: Zap },
    { id: 'Development', name: 'Development', icon: Briefcase },
    { id: 'Writing', name: 'Writing', icon: TrendingUp },
    { id: 'Marketing', name: 'Marketing', icon: ShieldCheck },
  ];

  useEffect(() => {
    const tasksRef = collection(db, 'tasks');
    let q = query(tasksRef);

    if (filter !== 'all') {
      q = query(tasksRef, where('status', '==', filter));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const taskList = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as Task))
        .sort((a, b) => {
          // Sort by featured first, then by date
          if ((a as any).isFeatured && !(b as any).isFeatured) return -1;
          if (!(a as any).isFeatured && (b as any).isFeatured) return 1;
          
          const dateA = a.createdAt instanceof Date ? a.createdAt : (a.createdAt as any).toDate();
          const dateB = b.createdAt instanceof Date ? b.createdAt : (b.createdAt as any).toDate();
          return dateB.getTime() - dateA.getTime();
        });
      setTasks(taskList);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, tasksRef.path);
    });

    return () => unsubscribe();
  }, [filter]);

  const filteredTasks = useMemo(() => {
    let result = tasks.filter(t => {
      const matchesSearch = t.title.toLowerCase().includes(appliedSearchTerm.toLowerCase()) ||
                          t.description.toLowerCase().includes(appliedSearchTerm.toLowerCase());
      const matchesCategory = category === 'all' || t.category === category;
      const matchesBudget = t.budget >= budgetRange[0] && t.budget <= budgetRange[1];
      return matchesSearch && matchesCategory && matchesBudget;
    });

    // Apply sorting
    return [...result].sort((a, b) => {
      // Always keep featured at the top if sorting by newest
      if (sortBy === 'newest') {
        if ((a as any).isFeatured && !(b as any).isFeatured) return -1;
        if (!(a as any).isFeatured && (b as any).isFeatured) return 1;
      }

      if (sortBy === 'budget-high') return b.budget - a.budget;
      if (sortBy === 'budget-low') return a.budget - b.budget;
      
      const dateA = a.createdAt instanceof Date ? a.createdAt : (a.createdAt as any).toDate();
      const dateB = b.createdAt instanceof Date ? b.createdAt : (b.createdAt as any).toDate();
      return dateB.getTime() - dateA.getTime();
    });
  }, [tasks, appliedSearchTerm, category, budgetRange, sortBy]);

  const liveSearchResults = useMemo(() => {
    if (!searchTerm.trim()) return [];
    return tasks.filter(t => 
      t.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.category?.toLowerCase().includes(searchTerm.toLowerCase())
    ).slice(0, 5);
  }, [tasks, searchTerm]);

  const smartSuggestions = useMemo(() => {
    if (!searchTerm.trim()) return [];
    // Find categories that match the search term or are related to live results
    const matchedCategories = new Set(liveSearchResults.map(t => t.category));
    
    // Also include categories that directly match the search term
    categories.forEach(cat => {
      if (cat.name.toLowerCase().includes(searchTerm.toLowerCase())) {
        matchedCategories.add(cat.id);
      }
    });

    return tasks
      .filter(t => matchedCategories.has(t.category) && !liveSearchResults.find(ls => ls.id === t.id))
      .slice(0, 3);
  }, [tasks, liveSearchResults, searchTerm, categories]);

  const handleApplySearch = (term: string = searchTerm) => {
    setAppliedSearchTerm(term);
    setSearchTerm(term);
    setIsSearchFocused(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleApplySearch();
    }
  };

  return (
    <div className="space-y-10">
      {/* Header Section */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-zinc-900 p-8 md:p-12 text-white shadow-2xl">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand-500/20 to-transparent pointer-events-none" />
        <div className="relative z-10 max-w-2xl">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-400 text-[10px] font-bold uppercase tracking-widest mb-6"
          >
            <Zap size={12} />
            Live Marketplace
          </motion.div>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
            Find your next <span className="text-brand-400">big opportunity</span>
          </h1>
          <p className="text-zinc-400 text-lg mb-8">
            Browse thousands of high-quality tasks from top clients around the world.
          </p>
          
          <div className="relative flex flex-col sm:flex-row gap-4">
            <AnimatePresence>
              {isSearchFocused && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setIsSearchFocused(false)}
                  className="fixed inset-0 bg-zinc-950/60 backdrop-blur-sm z-40"
                />
              )}
            </AnimatePresence>

            <div className={cn(
              "relative flex-1 z-50 transition-all duration-300",
              isSearchFocused && "scale-[1.02]"
            )}>
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
              <input
                type="text"
                placeholder="Search by title, skill, or keyword..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onKeyDown={handleKeyDown}
                className="w-full pl-12 pr-4 py-4 bg-white/10 border border-white/10 rounded-2xl focus:ring-4 focus:ring-brand-500/20 focus:bg-white focus:text-zinc-900 outline-none transition-all placeholder:text-zinc-600"
              />

              {/* Search Dropdown Overlay */}
              <AnimatePresence>
                {isSearchFocused && searchTerm.trim() && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 right-0 mt-4 bg-white rounded-3xl shadow-2xl border border-zinc-200 overflow-hidden z-50 text-zinc-900"
                  >
                    <div className="max-h-[450px] overflow-y-auto no-scrollbar p-2">
                      {/* Search Results Section */}
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-xs font-extrabold text-zinc-400 uppercase tracking-widest">Search Results</h3>
                          <span className="text-[10px] font-bold bg-zinc-100 text-zinc-500 px-2 py-0.5 rounded-full">{liveSearchResults.length} found</span>
                        </div>
                        <div className="space-y-2">
                          {liveSearchResults.map(task => (
                            <Link 
                              key={task.id}
                              to={`/tasks/${task.id}`}
                              onClick={() => setIsSearchFocused(false)}
                              className="flex items-center gap-4 p-3 rounded-2xl hover:bg-zinc-50 transition-colors group"
                            >
                              <div className="w-10 h-10 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                                <Briefcase size={20} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <h4 className="font-bold text-sm text-zinc-900 truncate">{task.title}</h4>
                                <p className="text-[10px] text-zinc-500 truncate">{task.category} • ${task.budget}</p>
                              </div>
                              <ArrowRight size={14} className="text-zinc-300 group-hover:text-brand-600 transition-colors" />
                            </Link>
                          ))}
                          {liveSearchResults.length === 0 && (
                            <p className="text-sm text-zinc-400 text-center py-4 italic">No direct matches found</p>
                          )}
                        </div>
                      </div>

                      {/* Visual Separator */}
                      <div className="h-px bg-zinc-100 mx-4" />

                      {/* Smart Suggestions Section */}
                      <div className="p-4">
                        <div className="flex items-center gap-2 mb-4">
                          <Zap size={14} className="text-brand-500" />
                          <h3 className="text-xs font-extrabold text-zinc-400 uppercase tracking-widest">Smart Suggestions</h3>
                        </div>
                        <div className="space-y-2">
                          {smartSuggestions.length > 0 ? (
                            smartSuggestions.map(task => (
                              <Link 
                                key={task.id}
                                to={`/tasks/${task.id}`}
                                onClick={() => setIsSearchFocused(false)}
                                className="flex items-center gap-4 p-3 rounded-2xl hover:bg-brand-50/50 transition-colors group border border-transparent hover:border-brand-100"
                              >
                                <div className="w-10 h-10 rounded-xl bg-zinc-50 text-zinc-400 flex items-center justify-center shrink-0 group-hover:bg-brand-100 group-hover:text-brand-600 transition-all">
                                  <Star size={18} />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-bold text-sm text-zinc-900 truncate">{task.title}</h4>
                                  <p className="text-[10px] text-zinc-500 truncate">Recommended in {task.category}</p>
                                </div>
                                <ArrowRight size={14} className="text-zinc-300 group-hover:text-brand-600 transition-colors" />
                              </Link>
                            ))
                          ) : (
                            <p className="text-sm text-zinc-400 text-center py-4 italic">Keep typing for suggestions</p>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="bg-zinc-50 p-3 text-center border-t border-zinc-100">
                      <button 
                        onClick={() => handleApplySearch()}
                        className="text-[10px] font-bold text-brand-600 hover:text-brand-700 uppercase tracking-widest transition-colors flex items-center justify-center gap-2 mx-auto"
                      >
                        <Search size={12} />
                        Press Enter to see all results
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <button 
              onClick={() => handleApplySearch()}
              className="relative z-50 px-8 py-4 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-brand-600/20 active:scale-95"
            >
              Search
            </button>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={cn(
                  "flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition-all",
                  category === cat.id 
                    ? "bg-zinc-900 text-white shadow-lg shadow-zinc-900/20" 
                    : "bg-white border border-zinc-200 text-zinc-500 hover:border-zinc-300"
                )}
              >
                <cat.icon size={16} />
                {cat.name}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={cn(
                "flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold border transition-all",
                showFilters ? "bg-brand-50 border-brand-200 text-brand-700" : "bg-white border-zinc-200 text-zinc-600 hover:border-zinc-300"
              )}
            >
              <Filter size={18} />
              Advanced Filters
            </button>
            <div className="h-8 w-px bg-zinc-200 mx-1 hidden lg:block" />
            <div className="flex items-center bg-white border border-zinc-200 rounded-xl p-1 shadow-sm">
              <button 
                onClick={() => setViewMode('grid')}
                className={cn("p-2 rounded-lg transition-colors", viewMode === 'grid' ? "bg-zinc-100 text-zinc-900" : "text-zinc-400 hover:text-zinc-600")}
                title="Grid View"
              >
                <LayoutGrid size={18} />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={cn("p-2 rounded-lg transition-colors", viewMode === 'list' ? "bg-zinc-100 text-zinc-900" : "text-zinc-400 hover:text-zinc-600")}
                title="List View"
              >
                <ListIcon size={18} />
              </button>
              <button 
                onClick={() => setViewMode('map')}
                className={cn("p-2 rounded-lg transition-colors", viewMode === 'map' ? "bg-zinc-100 text-zinc-900" : "text-zinc-400 hover:text-zinc-600")}
                title="Map View"
              >
                <MapIcon size={18} />
              </button>
            </div>
            
            <div className="relative">
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="appearance-none pl-4 pr-10 py-2.5 bg-white border border-zinc-200 rounded-xl focus:ring-4 focus:ring-brand-500/10 outline-none text-sm font-bold text-zinc-700 shadow-sm min-w-[140px]"
              >
                <option value="all">All Status</option>
                <option value="open">Open</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
              <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" size={16} />
            </div>
          </div>
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-xl grid grid-cols-1 md:grid-cols-3 gap-10">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-extrabold text-zinc-400 uppercase tracking-widest">Budget Range</label>
                    <span className="text-sm font-bold text-brand-600">${budgetRange[0]} - ${budgetRange[1]}+</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="10000" 
                    step="100"
                    value={budgetRange[1]}
                    onChange={(e) => setBudgetRange([budgetRange[0], parseInt(e.target.value)])}
                    className="w-full h-2 bg-zinc-100 rounded-lg appearance-none cursor-pointer accent-brand-600"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-zinc-400">
                    <span>$0</span>
                    <span>$10,000+</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="block text-xs font-extrabold text-zinc-400 uppercase tracking-widest">Sort Results</label>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { id: 'newest', label: 'Newest First' },
                      { id: 'budget-high', label: 'Highest Budget' },
                      { id: 'budget-low', label: 'Lowest Budget' },
                    ].map(option => (
                      <button
                        key={option.id}
                        onClick={() => setSortBy(option.id as any)}
                        className={cn(
                          "flex items-center justify-between px-4 py-3 rounded-xl text-sm font-bold transition-all border",
                          sortBy === option.id 
                            ? "bg-brand-50 border-brand-200 text-brand-700 shadow-sm" 
                            : "bg-zinc-50 border-transparent text-zinc-600 hover:bg-zinc-100"
                        )}
                      >
                        {option.label}
                        {sortBy === option.id && <CheckCircle2 size={16} />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="block text-xs font-extrabold text-zinc-400 uppercase tracking-widest">Quick Actions</label>
                  <div className="space-y-3">
                    <button 
                      onClick={() => {
                        setBudgetRange([0, 10000]);
                        setCategory('all');
                        setSortBy('newest');
                        setAppliedSearchTerm('');
                        setSearchTerm('');
                      }}
                      className="w-full py-3 rounded-xl text-sm font-bold bg-zinc-900 text-white hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-900/20"
                    >
                      Reset All Filters
                    </button>
                    <p className="text-[10px] text-zinc-400 text-center font-medium">
                      Showing {filteredTasks.length} of {tasks.length} tasks
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Tasks Grid / Map */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-64 bg-white border border-zinc-200 rounded-[2rem] animate-pulse p-6">
              <div className="w-12 h-12 bg-zinc-100 rounded-2xl mb-4" />
              <div className="h-6 bg-zinc-100 rounded-lg w-3/4 mb-2" />
              <div className="h-4 bg-zinc-100 rounded-lg w-full mb-2" />
              <div className="h-4 bg-zinc-100 rounded-lg w-1/2" />
            </div>
          ))}
        </div>
      ) : viewMode === 'map' ? (
        <motion.div 
          key="map"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="h-[600px] bg-white rounded-[2.5rem] border border-zinc-200 overflow-hidden shadow-sm relative"
        >
          {!hasValidKey ? (
            <div className="absolute inset-0 flex items-center justify-center p-8 bg-zinc-50/80 backdrop-blur-sm z-10">
              <div className="text-center max-w-md">
                <div className="w-16 h-16 bg-brand-100 rounded-2xl flex items-center justify-center mx-auto mb-6 text-brand-600">
                  <MapIcon size={32} />
                </div>
                <h2 className="text-2xl font-bold text-zinc-900 mb-4">Google Maps API Key Required</h2>
                <p className="text-sm text-zinc-500 mb-8 leading-relaxed">
                  To enable the interactive map view and see multiple task locations, you'll need to add your Google Maps API key.
                </p>
                <div className="space-y-4 text-left bg-white p-6 rounded-2xl border border-zinc-200 shadow-sm">
                  <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Setup Instructions</p>
                  <ol className="text-xs text-zinc-600 space-y-3 list-decimal pl-4">
                    <li>Get an API key from the <a href="https://console.cloud.google.com/google/maps-apis/credentials" target="_blank" rel="noopener" className="text-brand-600 font-bold hover:underline">Google Cloud Console</a>.</li>
                    <li>Open <strong>Settings</strong> (⚙️ gear icon, top-right) → <strong>Secrets</strong>.</li>
                    <li>Add <code>GOOGLE_MAPS_PLATFORM_KEY</code> as the name and your key as the value.</li>
                  </ol>
                </div>
              </div>
            </div>
          ) : (
            <APIProvider apiKey={API_KEY} version="weekly">
              <Map
                defaultCenter={{ lat: 37.7749, lng: -122.4194 }}
                defaultZoom={12}
                mapId="DEMO_MAP_ID"
                {...({ internalUsageAttributionIds: ['gmp_mcp_codeassist_v1_aistudio'] } as any)}
                style={{ width: '100%', height: '100%' }}
              >
                {filteredTasks.map(task => (
                  <MarkerWithInfoWindow key={task.id} task={task} />
                ))}
              </Map>
            </APIProvider>
          )}
        </motion.div>
      ) : (
        <div className={cn(
          "grid gap-6",
          viewMode === 'grid' ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-3" : "grid-cols-1"
        )}>
          <AnimatePresence mode="popLayout">
            {filteredTasks.length > 0 ? (
              filteredTasks.map((task, index) => (
                <motion.div
                  key={task.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.2, delay: index * 0.05 }}
                >
                  <Link 
                    to={`/tasks/${task.id}`}
                    className={cn(
                      "group block bg-white p-6 rounded-[2rem] border transition-all duration-300 relative overflow-hidden",
                      (task as any).isFeatured 
                        ? "border-amber-200 shadow-xl shadow-amber-500/10 bg-gradient-to-br from-white to-amber-50/30" 
                        : "border-zinc-200 shadow-sm hover:shadow-2xl hover:shadow-brand-500/10 hover:border-brand-200",
                      viewMode === 'list' && "flex items-center gap-6"
                    )}
                  >
                    {(task as any).isFeatured && (
                      <div className="absolute top-0 right-0">
                        <div className="bg-amber-500 text-white text-[8px] font-black uppercase tracking-widest px-4 py-1 rotate-45 translate-x-3 translate-y-1 shadow-sm">
                          Featured
                        </div>
                      </div>
                    )}
                    <div className={cn(
                      "flex justify-between items-start mb-6",
                      viewMode === 'list' && "mb-0 shrink-0"
                    )}>
                      {task.imageUrl ? (
                        <div className="w-14 h-14 rounded-2xl overflow-hidden shadow-inner group-hover:scale-110 transition-transform duration-300">
                          <img src={task.imageUrl} alt={task.title} className="w-full h-full object-cover" />
                        </div>
                      ) : (
                        <div className="w-14 h-14 rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform duration-300">
                          <Briefcase size={28} />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 bg-brand-50 px-2 py-1 rounded-md">
                          {task.category || 'General'}
                        </span>
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                          task.status === 'open' ? "bg-emerald-100 text-emerald-700" :
                          task.status === 'in-progress' ? "bg-blue-100 text-blue-700" :
                          "bg-zinc-100 text-zinc-700"
                        )}>
                          {task.status}
                        </span>
                      </div>
                      
                      <h3 className="text-xl font-extrabold text-zinc-900 group-hover:text-brand-600 transition-colors line-clamp-1">{task.title}</h3>
                      <p className="text-sm text-zinc-500 mt-2 line-clamp-2 leading-relaxed">{task.description}</p>
                      
                      <div className="mt-8 pt-6 border-t border-zinc-100 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-tighter">Budget</span>
                            <div className="flex items-center gap-1 text-zinc-900">
                              <DollarSign size={14} className="text-brand-500" />
                              <span className="text-lg font-extrabold tracking-tight">{task.budget}</span>
                            </div>
                          </div>
                          <div className="h-8 w-px bg-zinc-100" />
                          <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-tighter">Posted</span>
                            <div className="flex items-center gap-1 text-zinc-500">
                              <Clock size={14} />
                              <span className="text-xs font-bold">{format(task.createdAt instanceof Date ? task.createdAt : (task.createdAt as any).toDate(), 'MMM d')}</span>
                            </div>
                          </div>
                        </div>
                        <div className="w-10 h-10 rounded-full bg-zinc-50 text-zinc-400 group-hover:bg-brand-600 group-hover:text-white flex items-center justify-center transition-all duration-300 shadow-sm">
                          <ArrowRight size={20} />
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="col-span-full py-32 text-center bg-white rounded-[3rem] border-2 border-dashed border-zinc-200"
              >
                <div className="w-24 h-24 bg-zinc-50 rounded-full flex items-center justify-center mx-auto mb-6 text-zinc-300">
                  <Search size={48} />
                </div>
                <h3 className="text-2xl font-extrabold text-zinc-900">No matching tasks</h3>
                <p className="text-zinc-500 mt-2 max-w-sm mx-auto">We couldn't find any tasks matching your current search or filters. Try broadening your criteria.</p>
                <button 
                  onClick={() => { setSearchTerm(''); setAppliedSearchTerm(''); setCategory('all'); setFilter('all'); }}
                  className="mt-8 px-6 py-3 bg-zinc-900 text-white font-bold rounded-2xl hover:bg-zinc-800 transition-all"
                >
                  Clear all filters
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
