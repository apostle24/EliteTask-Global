import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, onSnapshot, orderBy, addDoc, serverTimestamp, doc, getDoc } from 'firebase/firestore';
import { Message, Task, UserProfile } from '../types';
import { useAuth } from '../hooks/useAuth';
import { Send, ArrowLeft, Info } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../utils/cn';

export default function Chat() {
  const { taskId } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [task, setTask] = useState<Task | null>(null);
  const [otherUser, setOtherUser] = useState<UserProfile | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!taskId || !profile) return;

    const fetchTask = async () => {
      try {
        const taskRef = doc(db, 'tasks', taskId);
        const taskDoc = await getDoc(taskRef).catch(err => handleFirestoreError(err, OperationType.GET, taskRef.path));
        if (taskDoc && taskDoc.exists()) {
          const taskData = { id: taskDoc.id, ...taskDoc.data() } as Task;
          setTask(taskData);
          
          // Find other user
          const otherId = profile.role === 'client' ? taskData.workerId : taskData.clientId;
          if (otherId) {
            const userRef = doc(db, 'users', otherId);
            const userDoc = await getDoc(userRef).catch(err => handleFirestoreError(err, OperationType.GET, userRef.path));
            if (userDoc && userDoc.exists()) {
              setOtherUser(userDoc.data() as UserProfile);
            }
          }
        }
      } catch (error) {
        console.error("Fetch task error:", error);
      }
    };

    fetchTask();

    const messagesRef = collection(db, 'tasks', taskId, 'messages');
    const q = query(messagesRef, orderBy('timestamp', 'asc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
      setMessages(msgList);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, messagesRef.path);
    });

    return () => unsubscribe();
  }, [taskId, profile]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskId || !newMessage.trim() || !profile || !otherUser) return;

    try {
      const messagesRef = collection(db, 'tasks', taskId, 'messages');
      await addDoc(messagesRef, {
        taskId,
        senderId: profile.uid,
        receiverId: otherUser.uid,
        content: newMessage.trim(),
        timestamp: serverTimestamp(),
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, messagesRef.path));
      setNewMessage('');
    } catch (err) {
      console.error("Send message error:", err);
    }
  };

  if (loading) return <div className="h-[70vh] flex items-center justify-center">
    <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
  </div>;

  return (
    <div className="h-[calc(100vh-120px)] flex flex-col bg-white rounded-3xl border border-zinc-200 shadow-sm overflow-hidden">
      {/* Chat Header */}
      <div className="p-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-zinc-200 rounded-full transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold overflow-hidden">
            {otherUser?.photoURL ? <img src={otherUser.photoURL} alt={otherUser.name} className="w-full h-full object-cover" /> : otherUser?.name?.charAt(0)}
          </div>
          <div>
            <h3 className="font-bold text-zinc-900">{otherUser?.name || 'User'}</h3>
            <p className="text-xs text-zinc-500 truncate max-w-[200px]">{task?.title}</p>
          </div>
        </div>
        <button className="p-2 text-zinc-400 hover:text-zinc-600">
          <Info size={20} />
        </button>
      </div>

      {/* Messages Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 bg-zinc-50/30">
        {messages.map((msg) => {
          const isMine = msg.senderId === profile?.uid;
          return (
            <div key={msg.id} className={cn(
              "flex flex-col max-w-[80%]",
              isMine ? "ml-auto items-end" : "mr-auto items-start"
            )}>
              <div className={cn(
                "px-4 py-3 rounded-2xl text-sm",
                isMine 
                  ? "bg-emerald-600 text-white rounded-tr-none" 
                  : "bg-white border border-zinc-200 text-zinc-900 rounded-tl-none shadow-sm"
              )}>
                {msg.content}
              </div>
              <span className="text-[10px] text-zinc-400 mt-1 px-1">
                {msg.timestamp ? format(msg.timestamp instanceof Date ? msg.timestamp : (msg.timestamp as any).toDate(), 'HH:mm') : '...'}
              </span>
            </div>
          );
        })}
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center p-12">
            <div className="w-16 h-16 bg-zinc-100 rounded-full flex items-center justify-center mb-4 text-zinc-400">
              <Send size={32} />
            </div>
            <h4 className="font-bold text-zinc-900">Start the conversation</h4>
            <p className="text-sm text-zinc-500 mt-1">Send a message to discuss the task details.</p>
          </div>
        )}
      </div>

      {/* Input Area */}
      <form onSubmit={handleSendMessage} className="p-4 border-t border-zinc-100 bg-white">
        <div className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 px-4 py-3 bg-zinc-100 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="w-12 h-12 bg-emerald-600 text-white rounded-2xl flex items-center justify-center hover:bg-emerald-700 transition-all disabled:opacity-50 disabled:bg-zinc-300"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
}
