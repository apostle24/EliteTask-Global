import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { db } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { 
  User, 
  Mail, 
  Briefcase, 
  FileText, 
  Save, 
  Check, 
  ShieldCheck, 
  ShieldAlert, 
  Shield, 
  Clock,
  Star,
  Zap,
  Sparkles,
  Wand2,
  Building2,
  CreditCard
} from 'lucide-react';
import { motion } from 'motion/react';
import { sendEmailVerification } from 'firebase/auth';
import { auth, handleFirestoreError, OperationType } from '../firebase';
import { GoogleGenAI } from "@google/genai";

export default function Profile() {
  const { profile } = useAuth();
  const [name, setName] = useState(profile?.name || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [skills, setSkills] = useState(profile?.skills?.join(', ') || '');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [verifyError, setVerifyError] = useState('');
  const [verifySuccess, setVerifySuccess] = useState('');
  
  const [isEditingTax, setIsEditingTax] = useState(false);
  const [taxId, setTaxId] = useState(profile?.taxDetails?.taxId || '');
  const [businessName, setBusinessName] = useState(profile?.taxDetails?.businessName || '');
  const [address, setAddress] = useState(profile?.taxDetails?.address || '');

  React.useEffect(() => {
    if (profile) {
      setName(profile.name);
      setBio(profile.bio || '');
      setSkills(profile.skills?.join(', ') || '');
      setTaxId(profile.taxDetails?.taxId || '');
      setBusinessName(profile.taxDetails?.businessName || '');
      setAddress(profile.taxDetails?.address || '');
    }
  }, [profile]);

  const handleAiSkillSummary = async () => {
    if (!profile?.skills || profile.skills.length === 0 || aiLoading) return;
    setAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      const prompt = `You are an expert personal branding consultant and career coach. 
      Write a compelling, high-impact professional bio (2-3 sentences) for a freelancer based on their skills.
      
      Skills: ${profile.skills.join(', ')}
      Name: ${profile.name}
      
      Instructions:
      1. Focus on the value provided to clients.
      2. Use strong action verbs and professional language.
      3. Make it sound unique and authoritative.
      4. Ensure it fits a modern, tech-forward marketplace.
      
      Return ONLY the bio text.`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });
      
      if (response.text) {
        setBio(response.text.trim());
        setVerifySuccess("AI generated bio! Don't forget to save changes.");
      }
    } catch (error) {
      console.error("AI Skill Summary error:", error);
      setVerifyError("Failed to generate bio.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleUpdateTax = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setLoading(true);
    try {
      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        taxDetails: {
          taxId,
          businessName,
          address
        }
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, userRef.path));
      setSuccess(true);
      setIsEditingTax(false);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error("Update tax error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setLoading(true);
    setSuccess(false);
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        name,
        bio,
        skills: skills.split(',').map(s => s.trim()).filter(s => s)
      });
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error("Profile update error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyEmail = async () => {
    if (!auth.currentUser) return;
    setVerifying(true);
    setVerifyError('');
    setVerifySuccess('');
    try {
      await sendEmailVerification(auth.currentUser);
      setVerifySuccess('Verification email sent! Please check your inbox.');
    } catch (err: any) {
      console.error("Email verification error:", err);
      setVerifyError(err.message || 'Failed to send verification email.');
    } finally {
      setVerifying(false);
    }
  };

  const handleRequestVerification = async () => {
    if (!profile) return;
    setVerifying(true);
    setVerifyError('');
    setVerifySuccess('');
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        verificationRequested: true,
        verificationDetails: `Skills: ${profile.skills?.join(', ')}`
      });
      setVerifySuccess('Verification request submitted! Our team will review your profile.');
    } catch (err: any) {
      console.error("Verification request error:", err);
      setVerifyError(err.message || 'Failed to submit verification request.');
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">My Profile</h1>
          <p className="text-zinc-500 mt-1">Manage your personal information and preferences.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-1">
          <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm text-center">
            <div className="relative inline-block">
              <div className="w-32 h-32 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 text-4xl font-bold overflow-hidden mx-auto mb-4 border-4 border-white shadow-sm">
                {profile?.photoURL ? <img src={profile.photoURL} alt={profile.name} className="w-full h-full object-cover" /> : profile?.name?.charAt(0)}
              </div>
              <button className="absolute bottom-4 right-0 p-2 bg-white rounded-full shadow-md border border-zinc-100 text-zinc-600 hover:text-emerald-600 transition-colors">
                <Save size={16} />
              </button>
            </div>
            <h2 className="text-xl font-bold text-zinc-900">{profile?.name}</h2>
            <p className="text-sm text-emerald-600 font-medium capitalize mb-4">{profile?.role}</p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100 text-center">
                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Credits</p>
                <div className="flex items-center justify-center gap-1 text-zinc-900 font-black text-lg">
                  <CreditCard size={16} className="text-zinc-400" />
                  {profile?.credits || 0}
                </div>
              </div>
              <div className="p-4 bg-brand-50 rounded-2xl border border-brand-100 text-center">
                <p className="text-[10px] font-bold text-brand-600 uppercase tracking-widest mb-1">Rating</p>
                <div className="flex items-center justify-center gap-1 text-brand-900 font-black text-lg">
                  <Star size={16} className="text-amber-400" fill="currentColor" />
                  {profile?.rating || '0.0'}
                </div>
              </div>
            </div>

            <div className="mb-6 p-4 rounded-2xl bg-zinc-50 border border-zinc-100 text-left">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Status</span>
                {profile?.verified ? (
                  <span className="flex items-center gap-1 text-emerald-600 text-xs font-bold">
                    <ShieldCheck size={14} /> Verified
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-amber-500 text-xs font-bold">
                    <ShieldAlert size={14} /> Unverified
                  </span>
                )}
              </div>
              
              {!profile?.verified && (
                <div className="space-y-3">
                  <p className="text-[10px] text-zinc-500 leading-relaxed">
                    {profile?.role === 'client' 
                      ? 'Verify your email to build trust with workers and post high-value tasks.'
                      : 'Get your skills verified to stand out and win more high-paying jobs.'}
                  </p>
                  
                  {verifyError && <p className="text-[10px] text-red-500 font-medium">{verifyError}</p>}
                  {verifySuccess && <p className="text-[10px] text-emerald-600 font-medium">{verifySuccess}</p>}

                  {profile?.role === 'client' ? (
                    <button
                      onClick={handleVerifyEmail}
                      disabled={verifying}
                      className="w-full py-2 bg-white border border-zinc-200 rounded-lg text-xs font-bold text-zinc-700 hover:bg-zinc-50 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {verifying ? 'Sending...' : (
                        <>
                          <Mail size={14} /> Verify Email
                        </>
                      )}
                    </button>
                  ) : (
                    <button
                      onClick={handleRequestVerification}
                      disabled={verifying || profile?.verificationRequested}
                      className="w-full py-2 bg-emerald-600 rounded-lg text-xs font-bold text-white hover:bg-emerald-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {verifying ? 'Submitting...' : profile?.verificationRequested ? (
                        <>
                          <Clock size={14} /> Under Review
                        </>
                      ) : (
                        <>
                          <Shield size={14} /> Request Verification
                        </>
                      )}
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="flex flex-wrap justify-center gap-2">
              {profile?.skills?.map(skill => (
                <span key={skill} className="px-3 py-1 bg-zinc-100 text-zinc-600 rounded-full text-xs font-medium">{skill}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Edit Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleUpdate} className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
            {success && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-emerald-50 text-emerald-700 p-4 rounded-xl text-sm font-medium border border-emerald-100 flex items-center gap-2"
              >
                <Check size={18} /> Profile updated successfully!
              </motion.div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-1 flex items-center gap-2">
                  <User size={16} /> Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-1 flex items-center gap-2">
                  <Mail size={16} /> Email Address
                </label>
                <input
                  type="email"
                  disabled
                  value={profile?.email || ''}
                  className="w-full px-4 py-3 border border-zinc-100 bg-zinc-50 rounded-xl text-zinc-500 cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-sm font-semibold text-zinc-700 flex items-center gap-2">
                  <FileText size={16} /> Bio
                </label>
                {profile?.role === 'worker' && profile.skills && profile.skills.length > 0 && (
                  <button
                    type="button"
                    onClick={handleAiSkillSummary}
                    disabled={aiLoading}
                    className="text-[10px] font-bold text-brand-600 hover:text-brand-500 flex items-center gap-1 bg-brand-50 px-2 py-1 rounded-lg transition-all disabled:opacity-50"
                  >
                    {aiLoading ? (
                      <div className="w-3 h-3 border-2 border-brand-600 border-t-transparent rounded-full animate-spin" />
                    ) : <Sparkles size={12} />}
                    AI Bio
                  </button>
                )}
              </div>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={4}
                className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none resize-none transition-all"
                placeholder="Tell the world about your expertise..."
              />
            </div>

            {/* Tax Details Section */}
            <div className="pt-6 border-t border-zinc-100 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2 uppercase tracking-wider">
                  <Building2 size={16} className="text-zinc-400" /> Tax & Business
                </h3>
                <button 
                  type="button"
                  onClick={() => setIsEditingTax(!isEditingTax)}
                  className="text-xs font-bold text-brand-600 hover:underline"
                >
                  {isEditingTax ? 'Cancel' : (profile?.taxDetails ? 'Edit' : 'Add Details')}
                </button>
              </div>

              {isEditingTax ? (
                <div className="space-y-4 bg-zinc-50 p-6 rounded-2xl border border-zinc-200">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Tax ID / VAT</label>
                      <input
                        type="text"
                        value={taxId}
                        onChange={(e) => setTaxId(e.target.value)}
                        className="w-full px-4 py-2 rounded-xl border border-zinc-200 outline-none focus:ring-2 focus:ring-brand-500 text-sm"
                        placeholder="e.g. US123456789"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Business Name</label>
                      <input
                        type="text"
                        value={businessName}
                        onChange={(e) => setBusinessName(e.target.value)}
                        className="w-full px-4 py-2 rounded-xl border border-zinc-200 outline-none focus:ring-2 focus:ring-brand-500 text-sm"
                        placeholder="e.g. Acme Corp"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Address</label>
                    <textarea
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      rows={2}
                      className="w-full px-4 py-2 rounded-xl border border-zinc-200 outline-none focus:ring-2 focus:ring-brand-500 resize-none text-sm"
                      placeholder="Full business address..."
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleUpdateTax}
                    disabled={loading}
                    className="w-full py-3 bg-zinc-900 text-white rounded-xl font-bold hover:bg-zinc-800 transition-all flex items-center justify-center gap-2 text-sm"
                  >
                    {loading ? 'Saving...' : 'Update Tax Details'}
                  </button>
                </div>
              ) : profile?.taxDetails ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-100">
                    <p className="text-[9px] font-bold text-zinc-400 uppercase mb-1">Tax ID</p>
                    <p className="text-xs font-bold text-zinc-900">{profile.taxDetails.taxId}</p>
                  </div>
                  <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-100">
                    <p className="text-[9px] font-bold text-zinc-400 uppercase mb-1">Business</p>
                    <p className="text-xs font-bold text-zinc-900 truncate">{profile.taxDetails.businessName}</p>
                  </div>
                  <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-100">
                    <p className="text-[9px] font-bold text-zinc-400 uppercase mb-1">Address</p>
                    <p className="text-xs font-bold text-zinc-900 truncate">{profile.taxDetails.address}</p>
                  </div>
                </div>
              ) : (
                <div className="p-6 bg-zinc-50 rounded-2xl border-2 border-dashed border-zinc-200 text-center">
                  <p className="text-xs text-zinc-500">No tax details provided. Required for professional invoicing.</p>
                </div>
              )}
            </div>

            {profile?.role === 'worker' && (
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-1 flex items-center gap-2">
                  <Briefcase size={16} /> Skills (comma separated)
                </label>
                <input
                  type="text"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                />
              </div>
            )}

            <div className="pt-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full sm:w-auto px-8 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? 'Saving...' : (
                  <>
                    <Save size={18} /> Save Changes
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
