import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { db, auth, storage, handleFirestoreError, OperationType } from '../firebase';
import { collection, doc, setDoc, serverTimestamp, updateDoc, increment } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { 
  Plus, 
  DollarSign, 
  Calendar, 
  Type, 
  AlignLeft,
  ArrowRight,
  Check,
  Image as ImageIcon,
  X,
  MapPin,
  Sparkles,
  Zap,
  ShieldAlert,
  CreditCard
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { APIProvider, Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';
import { useAuth } from '../hooks/useAuth';
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

import { automationService } from '../services/automationService';

export default function PostTask() {
  const { profile } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [budget, setBudget] = useState('');
  const [deadline, setDeadline] = useState('');
  const [category, setCategory] = useState('Development');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [lat, setLat] = useState<number | null>(null);
  const [lng, setLng] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [aiGenerated, setAiGenerated] = useState(false);
  const [testQuestions, setTestQuestions] = useState<{ question: string; type: 'text' | 'multiple-choice'; options?: string[] }[]>([]);
  const [testLoading, setTestLoading] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  const navigate = useNavigate();

  const TASK_COST = 1; // Cost in credits to post a task
  const FEATURED_COST = 2; // Cost in credits to post a featured task
  const currentCost = isFeatured ? FEATURED_COST : TASK_COST;

  const handleGenerateTest = async () => {
    if (!description || testLoading) return;
    setTestLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      const prompt = `You are a world-class technical recruiter and subject matter expert. 
      Based on the following task description, generate a comprehensive assessment test to evaluate a candidate's skills.
      
      Task Title: ${title}
      Task Description: ${description}
      
      Generate 4-6 high-quality questions that test both technical knowledge and practical experience.
      Include a mix of multiple-choice and open-ended questions.
      
      Return the questions in a JSON array format. Each object should have:
      - "question": The text of the question.
      - "type": Either "text" or "multiple-choice".
      - "options": An array of strings (only if type is "multiple-choice").
      
      Ensure the questions are challenging and relevant to the specific task.`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });
      
      if (response.text) {
        const questions = JSON.parse(response.text);
        setTestQuestions(questions);
      }
    } catch (error) {
      console.error("AI Test generation error:", error);
    } finally {
      setTestLoading(false);
    }
  };

  const handleAiPolish = async () => {
    if (!description || aiLoading) return;
    setAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      const prompt = `You are a professional project manager and copywriter. 
      Your goal is to take a rough task description and turn it into a high-quality, professional project brief that attracts the best freelancers.
      
      Task Title: ${title}
      Original Description: ${description}
      
      Instructions:
      1. Improve clarity and professionalism.
      2. Use a structured format (e.g., Overview, Key Responsibilities, Requirements).
      3. Maintain all original technical details and constraints.
      4. Make the tone confident and inviting.
      5. Keep it concise but thorough.
      
      Return ONLY the polished description text in Markdown format if appropriate, but avoid excessive formatting.`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });
      
      if (response.text) {
        setDescription(response.text.trim());
        setAiGenerated(true);
      }
    } catch (error) {
      console.error("AI Polish error:", error);
    } finally {
      setAiLoading(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !profile) return;

    // Check credits
    if (!profile.isPremium && profile.credits < currentCost) {
      alert("You don't have enough credits to post this task. Please upgrade to Premium or buy more credits.");
      return;
    }

    setLoading(true);
    try {
      // Generate a new document reference to get the ID first
      const taskRef = doc(collection(db, 'tasks'));
      let imageUrl = '';

      if (image) {
        // Use the generated task ID in the storage path
        const storageRef = ref(storage, `tasks/${taskRef.id}/image`);
        const snapshot = await uploadBytes(storageRef, image);
        imageUrl = await getDownloadURL(snapshot.ref);
      }

      await setDoc(taskRef, {
        title,
        description,
        budget: Number(budget),
        deadline: new Date(deadline),
        category,
        imageUrl,
        lat,
        lng,
        status: 'open',
        clientId: auth.currentUser.uid,
        aiGenerated,
        testQuestions,
        isFeatured,
        paymentStatus: 'pending',
        createdAt: serverTimestamp(),
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, taskRef.path));

      // Deduct credit if not premium
      if (!profile.isPremium) {
        const userRef = doc(db, 'users', auth.currentUser.uid);
        await updateDoc(userRef, {
          credits: increment(-currentCost)
        }).catch(err => handleFirestoreError(err, OperationType.UPDATE, userRef.path));
      }

      // Trigger Smart Match Automation
      await automationService.matchAndNotifyWorkers({
        id: taskRef.id,
        title,
        description,
        category,
      });

      setSuccess(true);
      setTimeout(() => navigate('/dashboard'), 2000);
    } catch (err) {
      console.error("Post task error:", err);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center">
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-6"
        >
          <Check size={40} />
        </motion.div>
        <h2 className="text-3xl font-bold text-zinc-900">Task Posted Successfully!</h2>
        <p className="text-zinc-500 mt-2">Redirecting you to your dashboard...</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">Post a New Task</h1>
        <p className="text-zinc-500 mt-1">Describe what you need and find the right expert.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-zinc-700 mb-1 flex items-center gap-2">
              <Type size={16} /> Task Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              placeholder="e.g. Build a React Dashboard"
            />
          </div>

          <div className="relative">
            <label className="block text-sm font-semibold text-zinc-700 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-2"><AlignLeft size={16} /> Description</span>
              <button
                type="button"
                onClick={handleAiPolish}
                disabled={!description || aiLoading}
                className="text-[10px] font-bold text-brand-600 hover:text-brand-500 flex items-center gap-1 bg-brand-50 px-2 py-1 rounded-lg transition-all disabled:opacity-50"
              >
                {aiLoading ? (
                  <div className="w-3 h-3 border-2 border-brand-600 border-t-transparent rounded-full animate-spin" />
                ) : <Sparkles size={12} />}
                Polish with AI
              </button>
            </label>
            <textarea
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none resize-none transition-all"
              placeholder="Describe the task in detail..."
            />
            {aiGenerated && (
              <div className="absolute bottom-3 right-3 flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">
                <Zap size={10} fill="currentColor" /> AI Enhanced
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-1 flex items-center gap-2">
                <DollarSign size={16} /> Budget ($)
              </label>
              <input
                type="number"
                required
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                placeholder="500"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-1 flex items-center gap-2">
                <Calendar size={16} /> Deadline
              </label>
              <input
                type="date"
                required
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-zinc-700 mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
            >
              <option>Development</option>
              <option>Design</option>
              <option>Writing</option>
              <option>Marketing</option>
              <option>Business</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-zinc-700 mb-2 flex items-center gap-2">
              <MapPin size={16} /> Task Location (Optional)
            </label>
            <div className="h-64 bg-zinc-50 rounded-2xl border border-zinc-200 overflow-hidden relative">
              {!hasValidKey ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                  <MapPin size={32} className="text-zinc-300 mb-2" />
                  <p className="text-xs text-zinc-400">
                    Google Maps API key required to pick a location. 
                    <br />
                    <span className="text-[10px] opacity-60">You can still post the task without a location.</span>
                  </p>
                </div>
              ) : (
                <APIProvider apiKey={API_KEY} version="weekly">
                  <Map
                    defaultCenter={{ lat: 37.7749, lng: -122.4194 }}
                    defaultZoom={12}
                    onClick={(e) => {
                      if (e.detail.latLng) {
                        setLat(e.detail.latLng.lat);
                        setLng(e.detail.latLng.lng);
                      }
                    }}
                    mapId="POST_TASK_MAP"
                    {...({ internalUsageAttributionIds: ['gmp_mcp_codeassist_v1_aistudio'] } as any)}
                    style={{ width: '100%', height: '100%' }}
                  >
                    {lat && lng && (
                      <AdvancedMarker position={{ lat, lng }}>
                        <Pin background="#10b981" glyphColor="#fff" />
                      </AdvancedMarker>
                    )}
                  </Map>
                </APIProvider>
              )}
              {lat && lng && (
                <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md p-3 rounded-xl border border-zinc-200 shadow-lg flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] font-bold text-zinc-600">Location Set: {lat.toFixed(4)}, {lng.toFixed(4)}</span>
                  </div>
                  <button 
                    type="button"
                    onClick={() => { setLat(null); setLng(null); }}
                    className="p-1 hover:bg-zinc-200 rounded-full transition-colors"
                  >
                    <X size={14} />
                  </button>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-zinc-700 mb-2 flex items-center justify-between">
              <span className="flex items-center gap-2"><AlignLeft size={16} /> AI Assessment Test (Optional)</span>
              <button
                type="button"
                onClick={handleGenerateTest}
                disabled={!description || testLoading}
                className="text-[10px] font-bold text-brand-600 hover:text-brand-500 flex items-center gap-1 bg-brand-50 px-2 py-1 rounded-lg transition-all disabled:opacity-50"
              >
                {testLoading ? (
                  <div className="w-3 h-3 border-2 border-brand-600 border-t-transparent rounded-full animate-spin" />
                ) : <Sparkles size={12} />}
                Generate Test with AI
              </button>
            </label>
            <div className="space-y-3">
              {testQuestions.map((q, idx) => (
                <div key={idx} className="p-4 rounded-xl border border-zinc-200 bg-zinc-50 relative group">
                  <button 
                    type="button"
                    onClick={() => setTestQuestions(testQuestions.filter((_, i) => i !== idx))}
                    className="absolute top-2 right-2 p-1 text-zinc-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X size={14} />
                  </button>
                  <p className="text-sm font-medium text-zinc-900 mb-1">{q.question}</p>
                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">{q.type}</p>
                  {q.type === 'multiple-choice' && q.options && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {q.options.map((opt, oIdx) => (
                        <span key={oIdx} className="px-2 py-1 rounded-md bg-white border border-zinc-200 text-[10px] text-zinc-600">{opt}</span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              {testQuestions.length === 0 && (
                <div className="p-4 rounded-xl border border-dashed border-zinc-200 text-center">
                  <p className="text-xs text-zinc-400 italic">No assessment test yet. Use AI to generate a comprehensive test based on your description.</p>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-zinc-700 mb-2 flex items-center gap-2">
              <ImageIcon size={16} /> Task Image (Optional)
            </label>
            <div className="flex items-center gap-4">
              <label className="flex flex-col items-center justify-center w-32 h-32 border-2 border-dashed border-zinc-200 rounded-2xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50 transition-all overflow-hidden relative group">
                {imagePreview ? (
                  <>
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        setImage(null);
                        setImagePreview(null);
                      }}
                      className="absolute top-1 right-1 p-1 bg-white/80 rounded-full text-zinc-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X size={16} />
                    </button>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Plus className="text-zinc-400 group-hover:text-emerald-500" />
                    <p className="text-xs text-zinc-400 mt-2">Upload</p>
                  </div>
                )}
                <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
              </label>
              <p className="text-xs text-zinc-400 max-w-[200px]">
                Adding an image helps experts understand your requirements better.
              </p>
            </div>
          </div>

          {/* Featured Upgrade Section */}
          <div className={`p-6 rounded-3xl border-2 transition-all ${isFeatured ? 'border-brand-500 bg-brand-50' : 'border-zinc-100 bg-zinc-50'}`}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm ${isFeatured ? 'bg-brand-600 text-white' : 'bg-white text-zinc-400'}`}>
                  <Zap size={24} fill={isFeatured ? "currentColor" : "none"} />
                </div>
                <div>
                  <h3 className="font-bold text-zinc-900 flex items-center gap-2">
                    Upgrade to Featured Task
                    <span className="px-2 py-0.5 rounded-full bg-brand-100 text-brand-700 text-[10px] font-black uppercase">Recommended</span>
                  </h3>
                  <p className="text-xs text-zinc-500 mt-1 leading-relaxed">
                    Featured tasks get 5x more visibility, priority matching with top-rated experts, and a special badge in the marketplace.
                  </p>
                  <div className="flex items-center gap-4 mt-3">
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-zinc-600">
                      <Check size={12} className="text-brand-600" /> 5x Visibility
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-zinc-600">
                      <Check size={12} className="text-brand-600" /> Priority Matching
                    </div>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsFeatured(!isFeatured)}
                className={`px-4 py-2 rounded-xl font-bold text-xs transition-all ${
                  isFeatured 
                  ? 'bg-brand-600 text-white shadow-lg shadow-brand-600/20' 
                  : 'bg-white text-zinc-900 border border-zinc-200 hover:border-brand-500'
                }`}
              >
                {isFeatured ? 'Selected' : 'Add +1 Credit'}
              </button>
            </div>
          </div>
        </div>

        <div className="pt-4 space-y-4">
          {!profile?.isPremium && (
            <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-zinc-400 shadow-sm">
                  <CreditCard size={20} />
                </div>
                <div>
                  <p className="text-sm font-bold text-zinc-900">Publishing Cost</p>
                  <p className="text-xs text-zinc-500">This will use {currentCost} {currentCost === 1 ? 'credit' : 'credits'}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-zinc-900">{profile?.credits || 0} Credits Left</p>
                <Link to="/upgrade" className="text-[10px] font-bold text-brand-600 hover:underline">Get more</Link>
              </div>
            </div>
          )}

          {profile?.isPremium && (
            <div className="p-4 bg-brand-50 rounded-2xl border border-brand-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-600 flex items-center justify-center text-white shadow-lg shadow-brand-600/20">
                <Zap size={20} fill="currentColor" />
              </div>
              <div>
                <p className="text-sm font-bold text-brand-900">Premium Publishing</p>
                <p className="text-xs text-brand-700">Unlimited free task publishing active {isFeatured && '(Featured included)'}</p>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || (!profile?.isPremium && (profile?.credits || 0) < currentCost)}
            className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
          >
            {loading ? 'Posting...' : (
              <>
                Post {isFeatured ? 'Featured' : ''} Task <ArrowRight size={20} />
              </>
            )}
          </button>
          
          {!profile?.isPremium && (profile?.credits || 0) < currentCost && (
            <div className="flex items-center gap-2 justify-center text-red-500 text-xs font-bold">
              <ShieldAlert size={14} />
              Insufficient credits. Please upgrade to publish.
            </div>
          )}
        </div>
      </form>
    </div>
  );
}
