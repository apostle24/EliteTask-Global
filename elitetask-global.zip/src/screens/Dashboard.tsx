import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, limit, getDocs } from 'firebase/firestore';
import { Task } from '../types';
import { 
  Plus, 
  Search, 
  Clock, 
  CheckCircle2, 
  TrendingUp, 
  ArrowRight,
  Briefcase,
  Users,
  Zap,
  Star,
  MessageSquare,
  ShieldCheck,
  ShieldAlert,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { cn } from '../utils/cn';
import { motion } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

export default function Dashboard() {
  const { profile } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [stats, setStats] = useState({ active: 0, completed: 0, total: 0, rating: 4.9 });
  const [loading, setLoading] = useState(true);
  const [recommendation, setRecommendation] = useState<string | null>(null);
  const [recLoading, setRecLoading] = useState(false);

  useEffect(() => {
    if (!profile) return;

    const tasksRef = collection(db, 'tasks');
    const q = query(
      tasksRef,
      where(profile.role === 'client' ? 'clientId' : 'workerId', '==', profile.uid),
      limit(20) // Fetch more to allow in-memory sorting
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const taskList = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as Task))
        .sort((a, b) => {
          const dateA = a.createdAt instanceof Date ? a.createdAt : (a.createdAt as any).toDate();
          const dateB = b.createdAt instanceof Date ? b.createdAt : (b.createdAt as any).toDate();
          return dateB.getTime() - dateA.getTime();
        })
        .slice(0, 5);
      
      setTasks(taskList);
      
      const active = taskList.filter(t => ['open', 'assigned', 'in-progress'].includes(t.status)).length;
      const completed = taskList.filter(t => t.status === 'completed').length;
      setStats(prev => ({ ...prev, active, completed, total: taskList.length }));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, tasksRef.path);
    });

    return () => unsubscribe();
  }, [profile]);

  const getSmartMatch = async () => {
    if (!profile || recLoading) return;
    setRecLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      // Fetch some open tasks to provide context
      const tasksRef = collection(db, 'tasks');
      const openTasksSnapshot = await getDocs(query(tasksRef, where('status', '==', 'open'), limit(3)))
        .catch(err => handleFirestoreError(err, OperationType.GET, tasksRef.path));
      if (!openTasksSnapshot) return;
      const openTasks = openTasksSnapshot.docs.map(d => d.data().title).join(', ');

      const prompt = `You are an AI assistant for EliteTask Global. 
      User Profile: Name: ${profile.name}, Role: ${profile.role}, Skills: ${profile.skills?.join(', ') || 'General'}.
      Available Tasks: ${openTasks || 'Various design and development tasks'}.
      Provide a short, professional, encouraging 2-sentence recommendation for what they should do next to grow their business on the platform.`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });
      setRecommendation(response.text || "Keep exploring the marketplace to find tasks that match your unique skills!");
    } catch (error) {
      console.error("AI Error:", error);
      setRecommendation("Focus on completing your active tasks to build a stronger profile and attract more opportunities.");
    } finally {
      setRecLoading(false);
    }
  };

  useEffect(() => {
    if (profile) getSmartMatch();
  }, [profile?.uid]);

  if (loading) return (
    <div className="animate-pulse space-y-10">
      <div className="h-64 bg-zinc-200 rounded-[3rem] w-full"></div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[1, 2, 3].map(i => <div key={i} className="h-32 bg-zinc-200 rounded-[2rem]"></div>)}
      </div>
    </div>
  );

  return (
    <div className="space-y-12">
      {/* Verification Banner */}
      {!profile?.verified && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 border border-amber-200 rounded-[2rem] p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600 shadow-inner">
              <ShieldAlert size={24} />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-amber-900 tracking-tight">Verify your profile</h3>
              <p className="text-amber-700 text-sm font-medium">
                {profile?.role === 'client' 
                  ? "Verify your email to build trust with workers and post more tasks."
                  : "Request skill verification to stand out and unlock higher-paying opportunities."}
              </p>
            </div>
          </div>
          <Link 
            to="/profile" 
            className="whitespace-nowrap px-6 py-3 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700 transition-all shadow-lg shadow-amber-600/20 active:scale-95"
          >
            Get Verified
          </Link>
        </motion.div>
      )}

      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-[3rem] bg-zinc-900 p-8 md:p-12 text-white shadow-2xl">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand-500/20 to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="max-w-xl">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-400 text-[10px] font-bold uppercase tracking-widest mb-6"
            >
              <Sparkles size={12} />
              Personalized Dashboard
            </motion.div>
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
              Welcome back, <span className="text-brand-400">{profile?.name?.split(' ')[0]}</span>
            </h1>
            <p className="text-zinc-400 text-lg leading-relaxed">
              {profile?.role === 'client' 
                ? "Manage your projects and hire top-tier talent from around the globe."
                : "Discover high-paying tasks and grow your professional portfolio today."}
            </p>
            
            <div className="mt-8 flex flex-wrap gap-4">
              {profile?.role === 'client' ? (
                <Link to="/post-task" className="bg-brand-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-brand-500 transition-all shadow-lg shadow-brand-600/20 active:scale-95">
                  <Plus size={20} /> Post a Task
                </Link>
              ) : (
                <Link to="/marketplace" className="bg-brand-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-brand-500 transition-all shadow-lg shadow-brand-600/20 active:scale-95">
                  <Search size={20} /> Browse Marketplace
                </Link>
              )}
              <button className="bg-white/10 text-white border border-white/10 px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-white/20 transition-all backdrop-blur-md">
                View Analytics
              </button>
            </div>
          </div>

          {/* AI Smart Match Card */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full md:w-80 glass rounded-[2.5rem] p-6 text-zinc-900 border-white/40"
          >
            <div className="flex items-center gap-2 text-brand-600 mb-4">
              <Zap size={18} fill="currentColor" />
              <span className="text-xs font-extrabold uppercase tracking-widest">Smart Match AI</span>
            </div>
            {recLoading ? (
              <div className="space-y-2 animate-pulse">
                <div className="h-3 bg-zinc-200 rounded w-full"></div>
                <div className="h-3 bg-zinc-200 rounded w-5/6"></div>
                <div className="h-3 bg-zinc-200 rounded w-4/6"></div>
              </div>
            ) : (
              <p className="text-sm font-medium leading-relaxed text-zinc-700 italic">
                "{recommendation}"
              </p>
            )}
            <button 
              onClick={getSmartMatch}
              className="mt-6 w-full py-3 rounded-xl bg-zinc-900 text-white text-xs font-bold hover:bg-zinc-800 transition-colors flex items-center justify-center gap-2"
            >
              Refresh Insights <ChevronRight size={14} />
            </button>
          </motion.div>
        </div>
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Active Projects" 
          value={stats.active} 
          icon={Clock} 
          color="text-blue-600" 
          bg="bg-blue-50" 
          trend="+12%"
        />
        <StatCard 
          title="Completed" 
          value={stats.completed} 
          icon={CheckCircle2} 
          color="text-emerald-600" 
          bg="bg-emerald-50" 
          trend="+5%"
        />
        <StatCard 
          title="Platform Rating" 
          value={stats.rating} 
          icon={Star} 
          color="text-amber-600" 
          bg="bg-amber-50" 
          trend="Top 1%"
        />
        <StatCard 
          title={profile?.role === 'client' ? "Total Spend" : "Total Earnings"} 
          value={profile?.role === 'client' ? `$${stats.total * 250}` : `$${stats.completed * 150}`}
          icon={TrendingUp} 
          color="text-brand-600" 
          bg="bg-brand-50" 
          trend="+24%"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Recent Activity */}
        <section className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-extrabold text-zinc-900 tracking-tight">Recent Activity</h2>
            <Link to="/marketplace" className="text-sm font-bold text-brand-600 hover:text-brand-500 flex items-center gap-1 group">
              View all tasks <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="bg-white border border-zinc-200 rounded-[2.5rem] overflow-hidden shadow-sm">
            {tasks.length > 0 ? (
              <div className="divide-y divide-zinc-100">
                {tasks.map((task) => (
                  <Link 
                    key={task.id} 
                    to={`/tasks/${task.id}`}
                    className="p-8 flex items-center gap-6 hover:bg-zinc-50 transition-all group"
                  >
                    {task.imageUrl ? (
                      <div className="w-14 h-14 rounded-2xl overflow-hidden shadow-inner group-hover:scale-110 transition-all">
                        <img src={task.imageUrl} alt={task.title} className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-14 h-14 rounded-2xl bg-zinc-50 flex items-center justify-center text-zinc-400 group-hover:bg-brand-50 group-hover:text-brand-600 transition-all shadow-inner">
                        <Briefcase size={28} />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-400">{task.category || 'General'}</span>
                        <div className="w-1 h-1 rounded-full bg-zinc-300" />
                        <span className="text-[10px] font-extrabold uppercase tracking-widest text-zinc-400">{format(task.createdAt instanceof Date ? task.createdAt : (task.createdAt as any).toDate(), 'MMM d')}</span>
                      </div>
                      <h3 className="text-lg font-extrabold text-zinc-900 truncate group-hover:text-brand-600 transition-colors">{task.title}</h3>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-extrabold text-zinc-900 tracking-tight">${task.budget}</p>
                      <span className={cn(
                        "inline-block px-3 py-1 rounded-full text-[10px] font-extrabold mt-1 uppercase tracking-widest",
                        task.status === 'open' ? "bg-emerald-100 text-emerald-700" :
                        task.status === 'in-progress' ? "bg-blue-100 text-blue-700" :
                        "bg-zinc-100 text-zinc-700"
                      )}>
                        {task.status}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="p-20 text-center">
                <div className="w-20 h-20 bg-zinc-50 rounded-full flex items-center justify-center mx-auto mb-6 text-zinc-300">
                  <Briefcase size={40} />
                </div>
                <h3 className="text-xl font-extrabold text-zinc-900">No activity yet</h3>
                <p className="text-zinc-500 mt-2 max-w-xs mx-auto">
                  {profile?.role === 'client' 
                    ? "Post your first task to start hiring world-class talent." 
                    : "Your journey starts here. Browse the marketplace for your first task."}
                </p>
                <Link 
                  to={profile?.role === 'client' ? "/post-task" : "/marketplace"}
                  className="mt-8 inline-flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white font-bold rounded-2xl hover:bg-zinc-800 transition-all"
                >
                  Get Started <ArrowRight size={18} />
                </Link>
              </div>
            )}
          </div>
        </section>

        {/* Sidebar Actions */}
        <aside className="space-y-8">
          <div className="bg-white border border-zinc-200 rounded-[2.5rem] p-8 shadow-sm">
            <h3 className="text-xl font-extrabold text-zinc-900 mb-6">Quick Actions</h3>
            <div className="space-y-3">
              <Link to="/post-task">
                <ActionButton icon={Plus} label="Create New Project" color="bg-brand-50 text-brand-600" />
              </Link>
              <Link to="/marketplace">
                <ActionButton icon={Search} label="Find Tasks" color="bg-blue-50 text-blue-600" />
              </Link>
              <Link to="/messages">
                <ActionButton icon={MessageSquare} label="Open Chats" color="bg-purple-50 text-purple-600" />
              </Link>
              <Link to="/profile">
                <ActionButton icon={ShieldCheck} label="Verify Profile" color="bg-emerald-50 text-emerald-600" />
              </Link>
            </div>
          </div>

          <div className="bg-gradient-to-br from-brand-600 to-brand-800 rounded-[2.5rem] p-8 text-white shadow-xl shadow-brand-600/20 relative overflow-hidden group">
            <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
            <div className="flex items-center justify-between mb-4 relative z-10">
              <h3 className="text-xl font-extrabold">Upgrade to Pro</h3>
              <div className="px-3 py-1 bg-white/20 rounded-lg text-[10px] font-black uppercase tracking-widest backdrop-blur-md">
                {profile?.credits || 0} Credits
              </div>
            </div>
            <p className="text-brand-100 text-sm mb-6 relative z-10">Get 0% service fees, priority support, and unlimited task posting.</p>
            <Link 
              to="/upgrade"
              className="w-full py-4 bg-white text-brand-700 font-extrabold rounded-2xl hover:bg-brand-50 transition-colors relative z-10 shadow-lg flex items-center justify-center gap-2"
            >
              Learn More <ArrowRight size={18} />
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, bg, trend }: any) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white p-8 rounded-[2.5rem] border border-zinc-200 shadow-sm flex flex-col gap-6 group hover:border-brand-200 transition-all duration-300"
    >
      <div className="flex justify-between items-start">
        <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner", bg, color)}>
          <Icon size={28} />
        </div>
        <span className="text-[10px] font-extrabold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">{trend}</span>
      </div>
      <div>
        <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">{title}</p>
        <p className="text-3xl font-extrabold text-zinc-900 tracking-tight group-hover:text-brand-600 transition-colors">{value}</p>
      </div>
    </motion.div>
  );
}

function ActionButton({ icon: Icon, label, color }: any) {
  return (
    <button className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-zinc-50 transition-all group">
      <div className="flex items-center gap-4">
        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", color)}>
          <Icon size={20} />
        </div>
        <span className="text-sm font-bold text-zinc-700 group-hover:text-zinc-900 transition-colors">{label}</span>
      </div>
      <ChevronRight size={16} className="text-zinc-300 group-hover:text-zinc-900 transition-colors" />
    </button>
  );
}
