import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { doc, getDoc, collection, addDoc, query, where, onSnapshot, serverTimestamp, updateDoc, orderBy } from 'firebase/firestore';
import { Task, Application, UserProfile, TimeLog } from '../types';
import { useAuth } from '../hooks/useAuth';
import { 
  Calendar, 
  DollarSign, 
  Briefcase, 
  User, 
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Star,
  Send,
  MessageSquare,
  ShieldCheck,
  Sparkles,
  Zap,
  Wand2,
  Timer,
  Play,
  Square,
  Clock,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../utils/cn';
import { APIProvider, Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

export default function TaskDetail() {
  const { taskId } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [task, setTask] = useState<Task | null>(null);
  const [client, setClient] = useState<UserProfile | null>(null);
  const [applications, setApplications] = useState<Application[]>([]);
  const [myApplication, setMyApplication] = useState<Application | null>(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [testAnswers, setTestAnswers] = useState<Record<number, string>>({});
  const [rating, setRating] = useState(5);
  const [review, setReview] = useState('');
  const [completing, setCompleting] = useState(false);
  const [showRatingForm, setShowRatingForm] = useState(false);

  // Time tracking state
  const [timeLogs, setTimeLogs] = useState<TimeLog[]>([]);
  const [isTracking, setIsTracking] = useState(false);
  const [currentLog, setCurrentLog] = useState<TimeLog | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [loadingTask, setLoadingTask] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isTracking) {
      timerRef.current = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isTracking]);

  const handleLoadTask = async () => {
    if (!taskId) return;
    setLoadingTask(true);
    try {
      const taskRef = doc(db, 'tasks', taskId);
      await updateDoc(taskRef, {
        status: 'in-progress'
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, taskRef.path));
      
      // Simulate loading assets/workspace
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      alert("Task workspace loaded successfully!");
    } catch (error) {
      console.error("Load task error:", error);
    } finally {
      setLoadingTask(false);
    }
  };

  const handleStartTracking = async () => {
    if (!taskId || !auth.currentUser) return;
    try {
      const logsRef = collection(db, 'tasks', taskId, 'timeLogs');
      const newLog = {
        workerId: auth.currentUser.uid,
        startTime: serverTimestamp(),
        description: 'Working on task'
      };
      const docRef = await addDoc(logsRef, newLog).catch(err => handleFirestoreError(err, OperationType.CREATE, logsRef.path));
      if (docRef) {
        setIsTracking(true);
        setElapsedTime(0);
        // We'll get the real ID from the snapshot listener
      }
    } catch (error) {
      console.error("Start tracking error:", error);
    }
  };

  const handleStopTracking = async () => {
    if (!taskId || !auth.currentUser || !currentLog) return;
    try {
      const logRef = doc(db, 'tasks', taskId, 'timeLogs', currentLog.id);
      const endTime = new Date();
      const startTime = currentLog.startTime instanceof Date ? currentLog.startTime : (currentLog.startTime as any).toDate();
      const duration = Math.floor((endTime.getTime() - startTime.getTime()) / 60000); // duration in minutes

      await updateDoc(logRef, {
        endTime: serverTimestamp(),
        duration: duration > 0 ? duration : 1
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, logRef.path));

      setIsTracking(false);
      setElapsedTime(0);
      setCurrentLog(null);
    } catch (error) {
      console.error("Stop tracking error:", error);
    }
  };

  const handleAiProposal = async () => {
    if (!task || aiLoading) return;
    setAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = "gemini-3-flash-preview";
      
      const prompt = `You are a top-rated freelancer on a global marketplace. 
      Write a highly persuasive, professional, and tailored proposal for the following task.
      
      Task Title: ${task.title}
      Task Description: ${task.description}
      Task Budget: ${task.budget}
      
      My Profile:
      Name: ${profile?.name}
      Bio: ${profile?.bio || 'Experienced professional'}
      Skills: ${profile?.skills?.join(', ') || 'General professional skills'}
      
      Instructions:
      1. Start with a strong hook that shows you understand the client's needs.
      2. Briefly explain why your specific skills make you the perfect fit.
      3. Mention how you would approach the task.
      4. Keep the tone professional, enthusiastic, and results-oriented.
      5. Keep it under 200 words.
      
      Return ONLY the proposal text.`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });
      
      if (response.text) {
        setCoverLetter(response.text.trim());
      }
    } catch (error) {
      console.error("AI Proposal error:", error);
    } finally {
      setAiLoading(false);
    }
  };

  useEffect(() => {
    if (!taskId) return;

    const fetchTask = async () => {
      try {
        const taskRef = doc(db, 'tasks', taskId);
        const taskDoc = await getDoc(taskRef).catch(err => handleFirestoreError(err, OperationType.GET, taskRef.path));
        if (taskDoc && taskDoc.exists()) {
          const taskData = { id: taskDoc.id, ...taskDoc.data() } as Task;
          setTask(taskData);
          
          // Fetch client profile
          const clientRef = doc(db, 'users', taskData.clientId);
          const clientDoc = await getDoc(clientRef).catch(err => handleFirestoreError(err, OperationType.GET, clientRef.path));
          if (clientDoc && clientDoc.exists()) {
            setClient(clientDoc.data() as UserProfile);
          }
        }
      } catch (error) {
        console.error("Fetch task error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTask();

    // Listen to applications
    const appsRef = collection(db, 'tasks', taskId, 'applications');
    const appsQuery = profile?.role === 'client' 
      ? query(appsRef)
      : query(appsRef, where('workerId', '==', auth.currentUser?.uid));

    const unsubscribeApps = onSnapshot(appsQuery, (snapshot) => {
      const appList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Application));
      
      if (profile?.role === 'client') {
        setApplications(appList);
      } else {
        const mine = appList.find(a => a.workerId === auth.currentUser?.uid);
        setMyApplication(mine || null);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `tasks/${taskId}/applications`);
    });

    // Listen to time logs
    const logsRef = collection(db, 'tasks', taskId, 'timeLogs');
    const logsQuery = query(logsRef, orderBy('startTime', 'desc'));
    const unsubscribeLogs = onSnapshot(logsQuery, (snapshot) => {
      const logs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TimeLog));
      setTimeLogs(logs);
      
      // Check if there's an active log
      const active = logs.find(l => !l.endTime && l.workerId === auth.currentUser?.uid);
      if (active) {
        setCurrentLog(active);
        setIsTracking(true);
        const start = active.startTime instanceof Date ? active.startTime : (active.startTime as any).toDate();
        setElapsedTime(Math.floor((new Date().getTime() - start.getTime()) / 1000));
      } else {
        setIsTracking(false);
        setCurrentLog(null);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `tasks/${taskId}/timeLogs`);
    });

    return () => {
      unsubscribeApps();
      unsubscribeLogs();
    };
  }, [taskId, profile?.role]);

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskId || !auth.currentUser || !profile || !task) return;
    setApplying(true);
    try {
      const appsRef = collection(db, 'tasks', taskId, 'applications');
      await addDoc(appsRef, {
        taskId,
        workerId: auth.currentUser.uid,
        workerName: profile.name,
        workerPhoto: profile.photoURL || '',
        coverLetter,
        testAnswers,
        status: 'pending',
        createdAt: serverTimestamp(),
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, appsRef.path));

      // Notify client
      const notifsRef = collection(db, 'users', task.clientId, 'notifications');
      await addDoc(notifsRef, {
        type: 'application',
        message: `${profile.name} applied for your task: ${task.title}`,
        taskId,
        read: false,
        createdAt: serverTimestamp(),
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, notifsRef.path));

      setCoverLetter('');
      setTestAnswers({});
    } catch (err) {
      console.error("Apply error:", err);
    } finally {
      setApplying(false);
    }
  };

  const handleAcceptApplication = async (app: Application) => {
    if (!task || !taskId) return;
    try {
      // Update task status and workerId
      const taskRef = doc(db, 'tasks', taskId);
      await updateDoc(taskRef, {
        status: 'assigned',
        workerId: app.workerId
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, taskRef.path));

      // Update application status
      const appRef = doc(db, 'tasks', taskId, 'applications', app.id);
      await updateDoc(appRef, {
        status: 'accepted'
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, appRef.path));

      // Notify worker
      const notifsRef = collection(db, 'users', app.workerId, 'notifications');
      await addDoc(notifsRef, {
        type: 'acceptance',
        message: `Congratulations! Your application for "${task.title}" was accepted.`,
        taskId,
        read: false,
        createdAt: serverTimestamp(),
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, notifsRef.path));

      // Reject others
      applications.forEach(async (a) => {
        if (a.id !== app.id) {
          const otherAppRef = doc(db, 'tasks', taskId, 'applications', a.id);
          await updateDoc(otherAppRef, {
            status: 'rejected'
          }).catch(err => handleFirestoreError(err, OperationType.UPDATE, otherAppRef.path));
        }
      });
    } catch (err) {
      console.error("Accept application error:", err);
    }
  };

  const handleCompleteTask = async () => {
    if (!task || !taskId || !task.workerId) return;
    setCompleting(true);
    try {
      const taskRef = doc(db, 'tasks', taskId);
      await updateDoc(taskRef, {
        status: 'completed',
        completedAt: serverTimestamp(),
        rating,
        review
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, taskRef.path));

      // Update worker's rating
      const workerRef = doc(db, 'users', task.workerId);
      const workerDoc = await getDoc(workerRef);
      if (workerDoc.exists()) {
        const workerData = workerDoc.data() as UserProfile;
        const currentRating = workerData.rating || 0;
        const currentCount = workerData.reviewCount || 0;
        const newCount = currentCount + 1;
        const newRating = ((currentRating * currentCount) + rating) / newCount;

        await updateDoc(workerRef, {
          rating: newRating,
          reviewCount: newCount
        }).catch(err => handleFirestoreError(err, OperationType.UPDATE, workerRef.path));
      }

      // Notify worker
      const notifsRef = collection(db, 'users', task.workerId, 'notifications');
      await addDoc(notifsRef, {
        type: 'completion',
        message: `Task "${task.title}" has been marked as completed. You received a ${rating}-star rating!`,
        taskId,
        read: false,
        createdAt: serverTimestamp(),
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, notifsRef.path));

      setShowRatingForm(false);
      alert("Task completed and review submitted!");
    } catch (err) {
      console.error("Complete task error:", err);
    } finally {
      setCompleting(false);
    }
  };

  if (loading) return <div className="animate-pulse space-y-6">
    <div className="h-8 bg-zinc-200 rounded w-1/3"></div>
    <div className="h-64 bg-zinc-200 rounded-3xl"></div>
  </div>;

  if (!task) return <div className="text-center py-20">Task not found</div>;

  const isOwner = profile?.uid === task.clientId;
  const isAssignedWorker = profile?.uid === task.workerId;

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-8">
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-zinc-500 hover:text-zinc-900 font-medium transition-colors"
      >
        <ArrowLeft size={20} /> Back to Marketplace
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Task Info */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest">{task.category}</span>
                  {(task as any).isFeatured && (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-brand-100 text-brand-700 text-[10px] font-black uppercase">
                      <Zap size={10} fill="currentColor" /> Featured
                    </span>
                  )}
                </div>
                <h1 className="text-3xl font-bold text-zinc-900 mt-1">{task.title}</h1>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-zinc-900">${task.budget}</p>
                <p className="text-sm text-zinc-500">Fixed Price</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-6 py-6 border-y border-zinc-100">
              <div className="flex items-center gap-2 text-zinc-600">
                <Calendar size={20} className="text-emerald-500" />
                <div className="text-sm">
                  <p className="font-bold">Deadline</p>
                  <p>{format(task.deadline instanceof Date ? task.deadline : (task.deadline as any).toDate(), 'MMM d, yyyy')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-zinc-600">
                <Briefcase size={20} className="text-emerald-500" />
                <div className="text-sm">
                  <p className="font-bold">Status</p>
                  <p className="capitalize">{task.status}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-zinc-600">
                <User size={20} className="text-emerald-500" />
                <div className="text-sm">
                  <p className="font-bold">Client</p>
                  <div className="flex items-center gap-1">
                    <p>{client?.name || 'Loading...'}</p>
                    {client?.verified && (
                      <ShieldCheck size={14} className="text-emerald-500" />
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-zinc-900">Description</h3>
              <p className="text-zinc-600 leading-relaxed whitespace-pre-wrap">{task.description}</p>
            </div>

            {task.testQuestions && task.testQuestions.length > 0 && (
              <div className="pt-6 border-t border-zinc-100">
                <h3 className="text-xl font-bold text-zinc-900 mb-4">Screening Questions</h3>
                <div className="space-y-4">
                  {task.testQuestions.map((q, idx) => (
                    <div key={idx} className="p-4 rounded-2xl bg-zinc-50 border border-zinc-100">
                      <p className="text-sm font-bold text-zinc-900 mb-2">{q.question}</p>
                      {q.type === 'multiple-choice' && q.options && (
                        <div className="flex flex-wrap gap-2">
                          {q.options.map((opt, oIdx) => (
                            <span key={oIdx} className="px-3 py-1 rounded-lg bg-white border border-zinc-200 text-xs text-zinc-600">{opt}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {task.imageUrl && (
              <div className="pt-6 border-t border-zinc-100">
                <h3 className="text-xl font-bold text-zinc-900 mb-4">Task Image</h3>
                <div className="rounded-3xl overflow-hidden border border-zinc-200 shadow-sm">
                  <img src={task.imageUrl} alt={task.title} className="w-full h-auto max-h-[500px] object-cover" />
                </div>
              </div>
            )}

            {task.lat && task.lng && (
              <div className="pt-6 border-t border-zinc-100">
                <h3 className="text-xl font-bold text-zinc-900 mb-4 flex items-center gap-2">
                  <CheckCircle2 size={24} className="text-emerald-500" /> Task Location
                </h3>
                <div className="h-64 bg-zinc-50 rounded-3xl border border-zinc-200 overflow-hidden relative">
                  {!hasValidKey ? (
                    <div className="absolute inset-0 flex items-center justify-center p-6 text-center">
                      <p className="text-xs text-zinc-400">Google Maps API key required to see location.</p>
                    </div>
                  ) : (
                    <APIProvider apiKey={API_KEY} version="weekly">
                      <Map
                        defaultCenter={{ lat: task.lat, lng: task.lng }}
                        defaultZoom={14}
                        mapId="TASK_DETAIL_MAP"
                        {...({ internalUsageAttributionIds: ['gmp_mcp_codeassist_v1_aistudio'] } as any)}
                        style={{ width: '100%', height: '100%' }}
                      >
                        <AdvancedMarker position={{ lat: task.lat, lng: task.lng }}>
                          <Pin background="#10b981" glyphColor="#fff" />
                        </AdvancedMarker>
                      </Map>
                    </APIProvider>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Load Task Section for Assigned Worker */}
          {isAssignedWorker && task.status === 'assigned' && (
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                  <Briefcase size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-zinc-900">Ready to Start?</h3>
                  <p className="text-sm text-zinc-500">Load the task workspace to begin working.</p>
                </div>
              </div>
              <button
                onClick={handleLoadTask}
                disabled={loadingTask}
                className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
              >
                {loadingTask ? (
                  <>
                    <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
                    Loading Workspace...
                  </>
                ) : (
                  <>Load Task Workspace <ArrowRight size={20} /></>
                )}
              </button>
            </div>
          )}

          {/* Time Tracking Section for Assigned Worker or Owner */}
          {(isAssignedWorker || isOwner) && task.status === 'in-progress' && (
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center">
                    <Timer size={20} />
                  </div>
                  <h3 className="text-xl font-bold text-zinc-900">Time Tracking</h3>
                </div>
                {isAssignedWorker && (
                  <button
                    onClick={isTracking ? handleStopTracking : handleStartTracking}
                    className={cn(
                      "flex items-center gap-2 px-6 py-2 rounded-xl font-bold transition-all",
                      isTracking 
                        ? "bg-red-100 text-red-600 hover:bg-red-200" 
                        : "bg-brand-600 text-white hover:bg-brand-700"
                    )}
                  >
                    {isTracking ? (
                      <><Square size={16} fill="currentColor" /> Stop Timer</>
                    ) : (
                      <><Play size={16} fill="currentColor" /> Start Timer</>
                    )}
                  </button>
                )}
              </div>

              {isTracking && isAssignedWorker && (
                <div className="p-6 rounded-2xl bg-brand-50 border border-brand-100 text-center">
                  <p className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-1">Active Session</p>
                  <p className="text-4xl font-black text-brand-900 font-mono">{formatTime(elapsedTime)}</p>
                </div>
              )}

              <div className="space-y-4">
                <h4 className="text-sm font-bold text-zinc-500 uppercase tracking-wider">Time Logs</h4>
                <div className="space-y-2">
                  {timeLogs.map((log) => (
                    <div key={log.id} className="flex items-center justify-between p-4 rounded-xl border border-zinc-100 hover:bg-zinc-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <Clock size={16} className="text-zinc-400" />
                        <div>
                          <p className="text-sm font-bold text-zinc-900">
                            {format(log.startTime instanceof Date ? log.startTime : (log.startTime as any).toDate(), 'MMM d, HH:mm')}
                          </p>
                          <p className="text-[10px] text-zinc-500">{log.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-zinc-900">
                          {log.duration ? `${log.duration}m` : (log.endTime ? 'Completed' : 'Active')}
                        </p>
                      </div>
                    </div>
                  ))}
                  {timeLogs.length === 0 && (
                    <p className="text-sm text-zinc-400 italic text-center py-4">No time logs yet.</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Applications Section */}
          {isOwner && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-zinc-900">Applicants ({applications.length})</h3>
              <div className="space-y-4">
                {applications.map((app) => (
                  <div key={app.id} className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm flex flex-col sm:flex-row gap-6">
                    <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold overflow-hidden shrink-0">
                      {app.workerPhoto ? <img src={app.workerPhoto} alt={app.workerName} className="w-full h-full object-cover" /> : app.workerName.charAt(0)}
                    </div>
                    <div className="flex-1 space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-zinc-900">{app.workerName}</h4>
                          <p className="text-xs text-zinc-500">{format(app.createdAt instanceof Date ? app.createdAt : (app.createdAt as any).toDate(), 'MMM d, yyyy')}</p>
                        </div>
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                          app.status === 'pending' ? "bg-amber-100 text-amber-700" :
                          app.status === 'accepted' ? "bg-emerald-100 text-emerald-700" :
                          "bg-red-100 text-red-700"
                        )}>
                          {app.status}
                        </span>
                      </div>
                      <p className="text-sm text-zinc-600 italic">"{app.coverLetter}"</p>
                      
                      {/* Display Test Answers */}
                      {(app as any).testAnswers && Object.keys((app as any).testAnswers).length > 0 && (
                        <div className="mt-4 p-4 rounded-xl bg-zinc-50 border border-zinc-100">
                          <p className="text-xs font-bold text-zinc-400 uppercase mb-2">Screening Answers</p>
                          <div className="space-y-3">
                            {task.testQuestions?.map((q, qIdx) => (
                              <div key={qIdx}>
                                <p className="text-[10px] font-bold text-zinc-600">{q.question}</p>
                                <p className="text-xs text-zinc-900">{(app as any).testAnswers[qIdx] || 'No answer'}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {task.status === 'open' && app.status === 'pending' && (
                        <div className="pt-4 flex gap-3">
                          <button 
                            onClick={() => handleAcceptApplication(app)}
                            className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-emerald-700 transition-colors"
                          >
                            Accept Application
                          </button>
                          <button className="border border-zinc-200 text-zinc-600 px-4 py-2 rounded-xl text-sm font-bold hover:bg-zinc-50 transition-colors">
                            View Profile
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {applications.length === 0 && (
                  <div className="bg-zinc-50 border-2 border-dashed border-zinc-200 p-12 rounded-3xl text-center">
                    <p className="text-zinc-500">No applications yet.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Actions */}
        <div className="space-y-6">
          {!isOwner && profile?.role === 'worker' && (
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
              {myApplication ? (
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-zinc-900">Application Sent</h3>
                  <p className="text-sm text-zinc-500">Status: <span className="font-bold capitalize text-emerald-600">{myApplication.status}</span></p>
                  {myApplication.status === 'accepted' && (
                    <Link 
                      to={`/tasks/${taskId}/chat`}
                      className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2"
                    >
                      <MessageSquare size={20} /> Open Chat
                    </Link>
                  )}
                </div>
              ) : task.status === 'open' ? (
                <form onSubmit={handleApply} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-zinc-900">Apply for this Task</h3>
                    <button
                      type="button"
                      onClick={handleAiProposal}
                      disabled={aiLoading}
                      className="text-[10px] font-bold text-brand-600 hover:text-brand-500 flex items-center gap-1 bg-brand-50 px-2 py-1 rounded-lg transition-all disabled:opacity-50"
                    >
                      {aiLoading ? (
                        <div className="w-3 h-3 border-2 border-brand-600 border-t-transparent rounded-full animate-spin" />
                      ) : <Wand2 size={12} />}
                      AI Proposal
                    </button>
                  </div>

                  {/* Test Questions in Application Form */}
                  {task.testQuestions && task.testQuestions.length > 0 && (
                    <div className="space-y-4 py-4 border-y border-zinc-100">
                      <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Screening Questions</p>
                      {task.testQuestions.map((q, idx) => (
                        <div key={idx} className="space-y-2">
                          <label className="text-sm font-medium text-zinc-700">{q.question}</label>
                          {q.type === 'multiple-choice' ? (
                            <div className="grid grid-cols-1 gap-2">
                              {q.options?.map((opt, oIdx) => (
                                <button
                                  key={oIdx}
                                  type="button"
                                  onClick={() => setTestAnswers({ ...testAnswers, [idx]: opt })}
                                  className={cn(
                                    "px-4 py-2 rounded-xl text-xs font-medium border transition-all text-left",
                                    testAnswers[idx] === opt 
                                      ? "bg-emerald-50 border-emerald-500 text-emerald-700" 
                                      : "bg-white border-zinc-200 text-zinc-600 hover:border-zinc-300"
                                  )}
                                >
                                  {opt}
                                </button>
                              ))}
                            </div>
                          ) : (
                            <input 
                              type="text"
                              value={testAnswers[idx] || ''}
                              onChange={(e) => setTestAnswers({ ...testAnswers, [idx]: e.target.value })}
                              className="w-full px-4 py-2 rounded-xl border border-zinc-200 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                              placeholder="Your answer..."
                            />
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-zinc-700 mb-1">Cover Letter</label>
                    <textarea
                      required
                      value={coverLetter}
                      onChange={(e) => setCoverLetter(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none resize-none transition-all"
                      placeholder="Why are you the best fit for this task?"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={applying}
                    className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {applying ? 'Sending...' : (
                      <>
                        Send Application <Send size={18} />
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <div className="text-center p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                  <p className="text-zinc-500 font-medium">This task is no longer accepting applications.</p>
                </div>
              )}
            </div>
          )}

          {isOwner && task.status === 'assigned' && (
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-4">
              <h3 className="text-xl font-bold text-zinc-900">Task Assigned</h3>
              <p className="text-sm text-zinc-500">You've hired an expert. Start collaborating!</p>
              <Link 
                to={`/tasks/${taskId}/chat`}
                className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2"
              >
                <MessageSquare size={20} /> Open Chat
              </Link>
            </div>
          )}

          {isOwner && task.status === 'in-progress' && (
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                  <CheckCircle2 size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-zinc-900">Complete Task</h3>
                  <p className="text-sm text-zinc-500">Mark this task as finished and rate the worker.</p>
                </div>
              </div>

              {!showRatingForm ? (
                <button
                  onClick={() => setShowRatingForm(true)}
                  className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                >
                  Mark as Completed <ArrowRight size={20} />
                </button>
              ) : (
                <div className="space-y-4 pt-4 border-t border-zinc-100">
                  <div>
                    <label className="block text-sm font-bold text-zinc-700 mb-2">Rate the Worker</label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setRating(star)}
                          className={cn(
                            "p-2 rounded-lg transition-all",
                            rating >= star ? "text-amber-500" : "text-zinc-200"
                          )}
                        >
                          <Star size={24} fill={rating >= star ? "currentColor" : "none"} />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-zinc-700 mb-2">Leave a Review</label>
                    <textarea
                      value={review}
                      onChange={(e) => setReview(e.target.value)}
                      rows={3}
                      className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none resize-none transition-all"
                      placeholder="Share your experience working with this expert..."
                    />
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowRatingForm(false)}
                      className="flex-1 py-3 border border-zinc-200 text-zinc-600 rounded-xl font-bold hover:bg-zinc-50 transition-all"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleCompleteTask}
                      disabled={completing}
                      className="flex-1 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all disabled:opacity-50"
                    >
                      {completing ? 'Submitting...' : 'Submit Review'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {task.status === 'completed' && (
            <div className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-zinc-900">Task Completed</h3>
                  <p className="text-sm text-zinc-500">This project was successfully finished.</p>
                </div>
              </div>
              
              {task.rating && (
                <div className="p-6 rounded-2xl bg-zinc-50 border border-zinc-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Client Review</span>
                    <div className="flex gap-0.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={star} 
                          size={14} 
                          className={cn(task.rating! >= star ? "text-amber-500" : "text-zinc-200")}
                          fill={task.rating! >= star ? "currentColor" : "none"}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-zinc-600 italic">"{task.review || 'No written review provided.'}"</p>
                </div>
              )}
            </div>
          )}

          <div className="bg-zinc-900 p-8 rounded-3xl text-white space-y-4">
            <h3 className="text-xl font-bold">Safety Tips</h3>
            <ul className="space-y-3 text-sm text-zinc-400">
              <li className="flex gap-2"><CheckCircle2 size={16} className="text-emerald-500 shrink-0" /> Never share personal contact info.</li>
              <li className="flex gap-2"><CheckCircle2 size={16} className="text-emerald-500 shrink-0" /> Keep all communication on Task Bridge.</li>
              <li className="flex gap-2"><CheckCircle2 size={16} className="text-emerald-500 shrink-0" /> Only pay through the platform.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
