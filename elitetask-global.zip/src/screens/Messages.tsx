import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { db } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, getDoc, doc } from 'firebase/firestore';
import { Task, Message } from '../types';
import { MessageSquare, ArrowRight, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { cn } from '../utils/cn';

export default function Messages() {
  const { profile } = useAuth();
  const [activeChats, setActiveChats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;

    // In a real app, we'd have a 'conversations' collection. 
    // Here we'll find tasks where the user is involved and has messages.
    const tasksRef = collection(db, 'tasks');
    const q = query(
      tasksRef,
      where(profile.role === 'client' ? 'clientId' : 'workerId', '==', profile.uid),
      where('status', 'in', ['assigned', 'in-progress', 'completed'])
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const chats = await Promise.all(snapshot.docs.map(async (taskDoc) => {
        const taskData = { id: taskDoc.id, ...taskDoc.data() } as Task;
        
        // Get other user info
        const otherId = profile.role === 'client' ? taskData.workerId : taskData.clientId;
        let otherName = 'User';
        if (otherId) {
          const userDoc = await getDoc(doc(db, 'users', otherId));
          if (userDoc.exists()) {
            otherName = userDoc.data().name;
          }
        }

        return {
          taskId: taskData.id,
          taskTitle: taskData.title,
          otherName,
          lastMessage: 'Click to open chat',
          timestamp: taskData.createdAt
        };
      }));
      
      setActiveChats(chats);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [profile]);

  if (loading) return <div className="animate-pulse space-y-4">
    {[1, 2, 3].map(i => <div key={i} className="h-24 bg-zinc-200 rounded-3xl"></div>)}
  </div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">Messages</h1>
        <p className="text-zinc-500 mt-1">Manage your active collaborations.</p>
      </div>

      <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
        {activeChats.length > 0 ? (
          <div className="divide-y divide-zinc-100">
            {activeChats.map((chat) => (
              <Link 
                key={chat.taskId} 
                to={`/tasks/${chat.taskId}/chat`}
                className="p-6 flex items-center gap-4 hover:bg-zinc-50 transition-colors"
              >
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                  <MessageSquare size={28} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h3 className="font-bold text-zinc-900 truncate">{chat.otherName}</h3>
                    <span className="text-[10px] text-zinc-400 flex items-center gap-1">
                      <Clock size={12} />
                      {format(chat.timestamp instanceof Date ? chat.timestamp : (chat.timestamp as any).toDate(), 'MMM d')}
                    </span>
                  </div>
                  <p className="text-sm text-zinc-500 font-medium truncate mt-1">{chat.taskTitle}</p>
                  <p className="text-xs text-emerald-600 mt-1">{chat.lastMessage}</p>
                </div>
                <ArrowRight size={20} className="text-zinc-300" />
              </Link>
            ))}
          </div>
        ) : (
          <div className="p-20 text-center">
            <div className="w-20 h-20 bg-zinc-100 rounded-full flex items-center justify-center mx-auto mb-4 text-zinc-400">
              <MessageSquare size={40} />
            </div>
            <h3 className="text-xl font-bold text-zinc-900">No active chats</h3>
            <p className="text-zinc-500 mt-2">Chats will appear here once a task is assigned.</p>
            <Link to="/marketplace" className="inline-block mt-6 text-emerald-600 font-bold hover:text-emerald-500">
              Browse tasks to get started
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
