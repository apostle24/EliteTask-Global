import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, updateDoc, doc } from 'firebase/firestore';
import { Notification } from '../types';
import { Bell, Check, Trash2, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../utils/cn';

export default function Notifications() {
  const { profile } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;

    const notifsRef = collection(db, 'users', profile.uid, 'notifications');
    const q = query(notifsRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notifList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification));
      setNotifications(notifList);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, notifsRef.path);
    });

    return () => unsubscribe();
  }, [profile]);

  const markAsRead = async (notifId: string) => {
    if (!profile) return;
    const notifRef = doc(db, 'users', profile.uid, 'notifications', notifId);
    await updateDoc(notifRef, {
      read: true
    }).catch(err => handleFirestoreError(err, OperationType.UPDATE, notifRef.path));
  };

  const markAllAsRead = async () => {
    if (!profile) return;
    notifications.forEach(async (n) => {
      if (!n.read) await markAsRead(n.id);
    });
  };

  if (loading) return <div className="animate-pulse space-y-4">
    {[1, 2, 3].map(i => <div key={i} className="h-20 bg-zinc-200 rounded-2xl"></div>)}
  </div>;

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">Notifications</h1>
          <p className="text-zinc-500 mt-1">Stay updated with your task activity.</p>
        </div>
        {notifications.some(n => !n.read) && (
          <button 
            onClick={markAllAsRead}
            className="text-sm font-semibold text-emerald-600 hover:text-emerald-500 flex items-center gap-1"
          >
            <Check size={16} /> Mark all as read
          </button>
        )}
      </div>

      <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
        {notifications.length > 0 ? (
          <div className="divide-y divide-zinc-100">
            {notifications.map((notif) => (
              <div 
                key={notif.id} 
                className={cn(
                  "p-6 flex items-start gap-4 transition-colors",
                  !notif.read ? "bg-emerald-50/30" : "hover:bg-zinc-50"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                  !notif.read ? "bg-emerald-100 text-emerald-600" : "bg-zinc-100 text-zinc-400"
                )}>
                  <Bell size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className={cn(
                    "text-sm",
                    !notif.read ? "text-zinc-900 font-semibold" : "text-zinc-600"
                  )}>
                    {notif.message}
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-[10px] text-zinc-400">
                    <Clock size={12} />
                    {format(notif.createdAt instanceof Date ? notif.createdAt : (notif.createdAt as any).toDate(), 'MMM d, HH:mm')}
                  </div>
                </div>
                {!notif.read && (
                  <button 
                    onClick={() => markAsRead(notif.id)}
                    className="p-2 text-zinc-400 hover:text-emerald-600 transition-colors"
                    title="Mark as read"
                  >
                    <Check size={18} />
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-zinc-100 rounded-full flex items-center justify-center mx-auto mb-4 text-zinc-400">
              <Bell size={32} />
            </div>
            <h3 className="text-lg font-bold text-zinc-900">No notifications</h3>
            <p className="text-zinc-500 mt-1">We'll notify you when something important happens.</p>
          </div>
        )}
      </div>
    </div>
  );
}
