import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { db, auth } from '../firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { UserProfile, UserRole } from '../types';
import { User, Briefcase, Camera, ArrowRight, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../utils/cn';

export default function Onboarding() {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState<UserRole | null>(null);
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [skills, setSkills] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleComplete = async () => {
    if (!auth.currentUser || !role) return;
    setLoading(true);
    try {
      const profile: Partial<UserProfile> = {
        uid: auth.currentUser.uid,
        name,
        email: auth.currentUser.email || '',
        role,
        verified: false,
        credits: 10, // Give 10 free credits to start
        isPremium: false,
        bio,
        skills: skills.split(',').map(s => s.trim()).filter(s => s),
        createdAt: serverTimestamp() as any,
      };
      await setDoc(doc(db, 'users', auth.currentUser.uid), profile);
      navigate('/dashboard');
    } catch (err) {
      console.error("Onboarding error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-xl">
        <div className="mb-10 flex justify-between items-center px-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center flex-1 last:flex-none">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300",
                step >= i ? "bg-emerald-600 text-white" : "bg-zinc-200 text-zinc-500"
              )}>
                {step > i ? <Check size={20} /> : i}
              </div>
              {i < 3 && (
                <div className={cn(
                  "flex-1 h-1 mx-4 rounded-full transition-all duration-300",
                  step > i ? "bg-emerald-600" : "bg-zinc-200"
                )} />
              )}
            </div>
          ))}
        </div>

        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-white p-8 rounded-3xl shadow-sm border border-zinc-200"
        >
          {step === 1 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-zinc-900">Choose your role</h2>
                <p className="text-zinc-500 mt-2">How do you plan to use Task Bridge Pro?</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  onClick={() => setRole('client')}
                  className={cn(
                    "p-6 rounded-2xl border-2 text-left transition-all",
                    role === 'client' ? "border-emerald-600 bg-emerald-50" : "border-zinc-100 hover:border-zinc-200"
                  )}
                >
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4">
                    <User size={24} />
                  </div>
                  <h3 className="font-bold text-lg">I'm a Client</h3>
                  <p className="text-sm text-zinc-500 mt-1">I want to post tasks and hire experts.</p>
                </button>
                <button
                  onClick={() => setRole('worker')}
                  className={cn(
                    "p-6 rounded-2xl border-2 text-left transition-all",
                    role === 'worker' ? "border-emerald-600 bg-emerald-50" : "border-zinc-100 hover:border-zinc-200"
                  )}
                >
                  <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mb-4">
                    <Briefcase size={24} />
                  </div>
                  <h3 className="font-bold text-lg">I'm a Worker</h3>
                  <p className="text-sm text-zinc-500 mt-1">I want to find tasks and earn money.</p>
                </button>
              </div>
              <button
                disabled={!role}
                onClick={() => setStep(2)}
                className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold disabled:opacity-50 flex items-center justify-center gap-2"
              >
                Continue <ArrowRight size={20} />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-zinc-900">Basic Information</h2>
                <p className="text-zinc-500 mt-2">Tell us a bit about yourself.</p>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-1">Bio</label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                    placeholder="Tell us about your experience..."
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <button onClick={() => setStep(1)} className="flex-1 py-4 border border-zinc-200 rounded-2xl font-bold text-zinc-600">Back</button>
                <button
                  disabled={!name}
                  onClick={() => setStep(3)}
                  className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-bold disabled:opacity-50"
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-zinc-900">Final Touches</h2>
                <p className="text-zinc-500 mt-2">
                  {role === 'worker' ? 'Add your skills to stand out.' : 'You are almost ready to post your first task!'}
                </p>
              </div>
              
              {role === 'worker' && (
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-1">Skills (comma separated)</label>
                  <input
                    type="text"
                    value={skills}
                    onChange={(e) => setSkills(e.target.value)}
                    className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    placeholder="React, Design, Writing..."
                  />
                </div>
              )}

              <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-emerald-200 flex items-center justify-center text-emerald-700 text-2xl font-bold">
                  {name.charAt(0) || 'U'}
                </div>
                <div>
                  <h4 className="font-bold text-zinc-900">{name || 'Your Name'}</h4>
                  <p className="text-sm text-emerald-600 capitalize">{role}</p>
                </div>
              </div>

              <div className="flex gap-4">
                <button onClick={() => setStep(2)} className="flex-1 py-4 border border-zinc-200 rounded-2xl font-bold text-zinc-600">Back</button>
                <button
                  disabled={loading}
                  onClick={handleComplete}
                  className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-bold disabled:opacity-50"
                >
                  {loading ? 'Setting up...' : 'Complete Setup'}
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
